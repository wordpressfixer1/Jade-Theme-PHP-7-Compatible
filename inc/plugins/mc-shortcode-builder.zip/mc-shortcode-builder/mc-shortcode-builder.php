<?php
/**
 * Elegant Shortcode Builder from MET Creative
 *
 * @package   MC_Shortcode_Builder
 * @author    Murat KARAÇAM <mail@mrtkrcm.com>
 * @license   You should have purchased a license from http://metcreative.com
 * @link      http://l.metc.in/mc-shortcode-builder
 * @copyright Copyright 2014 Murat KARAÇAM, MET Creative http://metcreative.com
 *
 * Plugin Name:       (mc) Shortcode Builder
 * Plugin URI:        http://l.metc.in/mc-shortcode-builder
 * Description:       Elegant Shortcode Builder from MET Creative
 * Version:           1.0.1
 * Author:            MET Creative
 * Author URI:        http://metcreative.com
 * Text Domain:       mcsb
 * License:           You should have purchased a license from http://metcreative.com
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'MCSB_VERSION', '1.0.1' );
define( 'MCSB_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'MCSB_DIR_NAME', dirname( plugin_basename( __FILE__ ) ) );
define( 'MCSB_ABS', dirname(__FILE__) );
define( 'MCSB_DEV_MODE', true );

require_once MCSB_ABS . '/class-mcsb-data.php';
require_once MCSB_ABS . '/class-mcsb.php';

new MC_Shortcode_Builder();

	/* Plugin Updates */
	require_once MCSB_ABS.'/wp-updates-plugin.php';
	new WPUpdatesPluginUpdater_661( 'http://wp-updates.com/api/2/plugin', plugin_basename(__FILE__));