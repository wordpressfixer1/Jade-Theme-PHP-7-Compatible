<?php
class MC_Shortcode_Builder_Data {
	function __construct(){
		add_action( 'init', array( $this, 'shortcodes' ) );
		add_filter( 'mcsb/data/shortcode', array( $this, 'shortcodes' ) );
	}

	function shortcodes($shortcode = false) {
		$shortcodes = apply_filters( 'mcsb/register/shortcode', array());
		return $shortcodes;
	}
}

new MC_Shortcode_Builder_Data;