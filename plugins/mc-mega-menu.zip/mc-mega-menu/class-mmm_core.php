<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( !class_exists( 'MET_Mega_Menu_Core' ) ){

	class MET_Mega_Menu_Core {
		protected $met_mega_menu_post_limit = 20;

		protected $met_mega_menu_sidebars_option_name = 'mc-mega-menu_sidebars';
		protected $met_mega_menu_sidebars_option_default = array();
		protected $met_mega_menu_sidebars = array();

		protected $met_mega_menu_nav_item = false;
		protected $met_mega_menu_nav_item_depth = 0;
		protected $met_mega_menu_nav_item_data = false;

		protected $met_mega_menu_sections = array();
		protected $met_mega_menu_options = array();
		protected $met_mega_menu_html_atts = array();

		/**
		 * MET_Mega_Menu_Core
		 *
		 * @since 1.0.0
		 */
		public function __construct(){
			add_action('admin_menu' , array( $this, 'met_mega_menu_admin_init' ) );

			add_action('wp_ajax_mmm-add-menu-item', array($this, 'met_mega_menu_admin_add_menu_item'));

			add_action('init', array($this, 'met_mega_menu_load_translation') );

			add_action( 'wp_enqueue_scripts', array( $this, 'met_mega_menu_enqueue_styles' ) );

			/* ------ */

			$this->met_mega_menu_sidebars_option_default = array('default-sidebar' => __('Default Sidebar','met_mega_menu'));

			add_action('init', array($this, 'met_mega_menu_sidebars_init') );

			add_action('wp_ajax_mmm-ajax', array($this, 'met_mega_menu_admin_ajax'));

			add_action('MMM_set_sections', array( $this , 'met_mega_menu_set_sections' ) );
			add_action('MMM_set_options', array( $this , 'met_mega_menu_set_options' ) );
			add_action('MMM_set_html_atts', array( $this , 'met_mega_menu_set_html_atts' ) );
			add_action('MMM_set_nav_item', array( $this , 'met_mega_menu_set_nav_item' ), 10, 2 );
			add_action('MMM_build_item_options', array( $this , 'met_mega_menu_build_item_options' ), 10, 2 );

			add_filter('MMM_filter_html_atts', array( $this , 'met_mega_menu_FILTER_html_atts' ) );
		}

		/**
		 * Load Plugin Text Domain
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_load_translation(){
			load_plugin_textdomain( 'met_mega_menu', false, MMM_DIR_NAME . '/languages/' );
		}

		function met_mega_menu_enqueue_styles(){
			wp_enqueue_style('mmm_style', MMM_DIR_URL.'css/mmm-style.css', array(), MMM_VERSION);
		}

		/**
		 * Menu Item Sections
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_set_sections(){
			$this->met_mega_menu_sections['menu_options'] = array(
				'title' => __('Menu Options','met_mega_menu'),
				'depth' => '0',
				'sub' => false
			);

			$this->met_mega_menu_sections['link_options'] = array(
				'title' => __('Display Options','met_mega_menu'),
				'depth' => 'all',
				'sub' => false
			);

			$this->met_mega_menu_sections['tab_category'] = array(
				'title' => __('Tab Category','met_mega_menu'),
				'depth' => '1',
				'sub' => array(
					'parent_section'	=> 'menu_options',
					'parent_option'		=> 'menu_type',
					'parent_value'		=> 'tabbed_posts'
				)
			);

			$this->met_mega_menu_sections['mega_menu_options'] = array(
				'title' => __('Mega Menu Options (Column)','met_mega_menu'),
				'depth' => '1',
				'sub' => array(
					'parent_section'	=> 'menu_options',
					'parent_option'		=> 'menu_type',
					'parent_value'		=> 'mega'
				)
			);
		}

		/**
		 * Menu Item Options
		 *
		 * @since 1.0.0
		 *
		 * @param int $section_id
		 */
		function met_mega_menu_set_options($section_id = 0){
			for($i = 1; $i <= $this->met_mega_menu_post_limit; $i++) $met_mega_nav_post_limit_arr[$i] = $i;
			$met_mega_submenu_align = array('0' => __( 'Theme Default' , 'met_mega_menu' ), 'left' => __( 'Left' , 'met_mega_menu' ), 'center' => __( 'Center' , 'met_mega_menu' ), 'right' => __( 'Right' , 'met_mega_menu' ));

			/**
			 * Section [Menu Options]
			 */
			$this->met_mega_menu_options['menu_options'] = array(
				array(
					'id' 		=> 'menu_type',
					'title'		=> __('Menu Type','met_mega_menu'),
					'type'		=> 'radio',
					'default'	=> '0',
					'options'	=> array(
						'0' 			=> __('Normal (Dropdown)','met_mega_menu'),
						'mega' 			=> __('Mega Menu','met_mega_menu'),
						'posts' 		=> __('Latest Posts','met_mega_menu'),
						'tabbed_posts' 	=> __('Tabbed Posts','met_mega_menu'),
						'advanced' 		=> __('Advanced (HTML)','met_mega_menu'),
						//'search' 		=> __('Search Form','met_mega_menu')
					),
					'releated_options' => array(
						'0' 		=> array(
							array(
								'id' 		=> 'dropdown_submenu_align',
								'title'		=> __('Submenu Align <small>Default: Left</small>','met_mega_menu'),
								'type'		=> 'select',
								'default'   => '0',
								'options'	=> $met_mega_submenu_align,
							),
						),
						'mega' 		=> array(
							array(
								'id' 		=> 'mega_submenu_full',
								'title'		=> __( 'Full Width Submenu?' , 'met_mega_menu' ),
								'type'		=> 'checkbox',
								'default'	=> ''
							),
							array(
								'id' 		=> 'mega_submenu_align',
								'title'		=> __('Submenu Align <small>Default: Center</small>','met_mega_menu'),
								'type'		=> 'select',
								'default'   => '0',
								'options'	=> $met_mega_submenu_align,
							),
							array(
								'id' 		=> 'tab_posts_note',
								'title'		=> __('Each first sub level menu acts as Column in this menu.','met_mega_menu'),
								'type'		=> 'note',
							),
						),
						'tabbed_posts' => array(
							array(
								'id' 		=> 'tab_posts_limit',
								'title'		=> __('Category Posts Limit:','met_mega_menu'),
								'type'		=> 'select',
								'options'	=> $met_mega_nav_post_limit_arr,
							),
							array(
								'id' 		=> 'tab_posts_submenu_align',
								'title'		=> __('Submenu Align <small>Default: Center</small>','met_mega_menu'),
								'type'		=> 'select',
								'default'   => '0',
								'options'	=> $met_mega_submenu_align,
							),
							array(
								'id' 		=> 'tab_posts_note',
								'title'		=> __('Each first sub level menu acts as Category Tab in this menu.','met_mega_menu'),
								'type'		=> 'note',
							),
						),
						'posts' => array(
							array(
								'id' 		=> 'posts_category',
								'title'		=> __('Select a Category','met_mega_menu'),
								'type'		=> 'category_select',
							),
							array(
								'id' 		=> 'posts_limit',
								'title'		=> __('Posts Limit','met_mega_menu'),
								'type'		=> 'select',
								'options'	=> $met_mega_nav_post_limit_arr,
							),
							array(
								'id' 		=> 'posts_submenu_align',
								'title'		=> __('Submenu Align <small>Default: Center</small>','met_mega_menu'),
								'type'		=> 'select',
								'default'   => '0',
								'options'	=> $met_mega_submenu_align,
							),
						),
						'advanced' => array(
							array(
								'id' 		=> 'html_content',
								'title'		=> __('Content (HTML/Shortcode)','met_mega_menu'),
								'type'		=> 'wp_editor',
							),
							array(
								'id' 		=> 'html_content_full',
								'title'		=> __( 'Full Width Content?' , 'met_mega_menu' ),
								'type'		=> 'checkbox',
								'default'	=> ''
							),
							array(
								'id' 		=> 'html_submenu_align',
								'title'		=> __('Submenu Align <small>Default: Center</small>','met_mega_menu'),
								'type'		=> 'select',
								'default'   => '0',
								'options'	=> $met_mega_submenu_align,
							),
						)
					)
				)
			);

			/**
			 * Section [Display Options]
			 */
			$this->met_mega_menu_options['link_options'] = array(
				array(
					'id' 		=> 'highlight_label',
					'title'		=> __('Highlight Label <small>(a.k.a: Column Title)</small>','met_mega_menu'),
					'type'		=> 'checkbox',
					'default'	=> ''
				),
				array(
					'id' 		=> 'disable_label',
					'title'		=> __('Disable Label','met_mega_menu'),
					'type'		=> 'checkbox',
					'default'	=> ''
				),
				array(
					'id' 		=> 'disable_link',
					'title'		=> __('Disable Link <small>(un-clickable)</small>','met_mega_menu'),
					'type'		=> 'checkbox',
					'default'	=> ''
				),
				array(
					'id' 		=> 'icon_type',
					'title'		=> __('Icon Type','met_mega_menu'),
					'type'		=> 'select',
					'options'	=> array('' => 'No Icon', 'fa' => 'Icon Selector', 'upload' =>'Upload', 'text' =>'Text'),
					'releated_options' => array(
						'' => array(),
						'fa' => array(
							array(
								'id' 		=> 'icon_fa',
								'title'		=> __( 'Select Icon' , 'met_mega_menu' ),
								'type'		=> 'fontawesome',
								'default'	=> ''
							),
							array(
								'id' 		=> 'icon_fa_color',
								'title'		=> __('Icon Color <small>Hex: #000000 or RGB: rgb(255,255,255)</small>','met_mega_menu'),
								'type'		=> 'text',
							),
						),
						'upload' => array(
							array(
								'id' 		=> 'icon_image',
								'title'		=> __('Icon','met_mega_menu'),
								'type'		=> 'upload',
							),
						),
						'text' => array(
							array(
								'id' 		=> 'icon_text',
								'title'		=> __('Text','met_mega_menu'),
								'type'		=> 'text',
							),
							array(
								'id' 		=> 'icon_text_color',
								'title'		=> __('Text Color <small>Hex: #000000 or RGB: rgb(255,255,255)</small>','met_mega_menu'),
								'type'		=> 'text',
							),
						),
					)
				),
			);

			/**
			 * Section [Tab Category]
			 * -> [menu_options]['menu_type'] = 'tabbed_posts'
			 */
			$this->met_mega_menu_options['tab_category'] = array(
				array(
					'id' 		=> 'tab_category',
					'title'		=> __('Select a Category','met_mega_menu'),
					'type'		=> 'category_select',
				)
			);

			$mega_menu_column_sizes = array('0' => 'Theme Default', '1' => '1','2' => '2','3' => '3 (Half)','4' => '4', '5' => '5','6' => '6 (Full)');
			/**
			 * Section [Mega Menu Options (Column)]
			 * -> [menu_options]['menu_type'] = 'mega'
			 */
			$this->met_mega_menu_options['mega_menu_options'] = array(
				array(
					'id' 		=> 'column_type',
					'title'		=> __('Column Type','met_mega_menu'),
					'type'		=> 'radio',
					'default'	=> 'link',
					'options'	=> array(
						'link' 		=> __('Menu Links','met_mega_menu'),
						'widget' 	=> __('Widget','met_mega_menu'),
						'advanced' 	=> __('Advanced (HTML)','met_mega_menu'),
						'divider' 	=> __('Divider <small>a.k.a: Start New Row</small>','met_mega_menu'),
					),
					'releated_options' => array(
						'dropdown' => array(),
						'link' => array(
							array(
								'id' 		=> 'column_type_link_note',
								'title'		=> __('Use sub levels as Links','met_mega_menu'),
								'type'		=> 'note',
							),
							array(
								'id' 		=> 'column_type_link_size',
								'title'		=> __('Column Size <small>(If "Full Width" Enabled)</small>','met_mega_menu'),
								'type'		=> 'select',
								'options'	=> $mega_menu_column_sizes
							),
						),
						'widget' => array(
							array(
								'id' 		=> 'column_type_widget_note',
								'title'		=> __('<ul><li>Select or Create a Sidebar below,</li><li>Go <strong>Appearance -> Widgets,</strong></li><li>Mega Menu Sidebars has prefix like: <strong>MC-MM:</strong></li></ul>','met_mega_menu'),
								'type'		=> 'note',
							),
							array(
								'id' 		=> 'sidebar',
								'title'		=> __('Widget Area','met_mega_menu'),
								'type'		=> 'select_sidebar',
								'options'	=> array_merge(array('' => __('Select Sidebar','met_mega_menu')), (array)$this->met_mega_menu_sidebars),
							),
							array(
								'id' 		=> 'column_type_widget_size',
								'title'		=> __('Column Size <small>(If "Full Width" Enabled)</small>','met_mega_menu'),
								'type'		=> 'select',
								'options'	=> $mega_menu_column_sizes
							),
						),
						'advanced' => array(
							array(
								'id' 		=> 'column_html_content',
								'title'		=> __('Content (HTML/Shortcode)','met_mega_menu'),
								'type'		=> 'wp_editor',
							),
							array(
								'id' 		=> 'column_html_content_size',
								'title'		=> __('Column Size <small>(If "Full Width" Enabled)</small>','met_mega_menu'),
								'type'		=> 'select',
								'options'	=> $mega_menu_column_sizes
							),
						),
						'divider' => array(
							array(
								'id' 		=> 'column_type_divider_note',
								'title'		=> __('Items after this will be a new row.','met_mega_menu'),
								'type'		=> 'note',
							),
						)
					)
				)
			);
		}

		/**
		 * HTML Elements Atts
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_set_html_atts(){
			$this->met_mega_menu_html_atts = array();

			/* Section */
			$this->met_mega_menu_html_atts['section']['class'] = array(
				'met_mega_menu_sections_box',
				'met_mega_menu_sections_inactive',
				'met_mega_menu_sections_box_{$section_id}',
				'met_mega_menu_sections_box'
			);
			$this->met_mega_menu_html_atts['section']['data-section_id'] = '{$section_id}';
			$this->met_mega_menu_html_atts['section']['data-depth'] = '{$section_depth}';
			$this->met_mega_menu_html_atts['section']['data-parent_section'] = '{$parent_section}';
			$this->met_mega_menu_html_atts['section']['data-parent_option'] = '{$parent_option}';
			$this->met_mega_menu_html_atts['section']['data-parent_value'] = '{$parent_value}';

			/* Option */
			$this->met_mega_menu_html_atts['option']['class'] 			= array(
				'met_mega_menu_{$option_type}',
				'met_mega_menu_{$option_ID}',
				'{$option_has_relation}',
			);
			$this->met_mega_menu_html_atts['option']['name'] 			= '{$option_ID}[{$item_ID}]';
			$this->met_mega_menu_html_atts['option']['id'] 				= 'edit-{$option_ID}-{$item_ID}';
			$this->met_mega_menu_html_atts['option']['value'] 			= '{$option_value}';


			/* Option -> radio */
			$this->met_mega_menu_html_atts['option_radio']['class'] 			= array(
				'met_mega_menu_{$option_type}',
				'met_mega_menu_{$option_ID}',
				'{$option_has_relation}',
			);
			$this->met_mega_menu_html_atts['option_radio']['name'] 				= '{$option_ID}[{$item_ID}]';
			$this->met_mega_menu_html_atts['option_radio']['value'] 			= '{$option_value}';
			$this->met_mega_menu_html_atts['option_radio']['id'] 				= 'edit-{$option_ID}-{$item_ID}-{$radio_optionKEY}';
			$this->met_mega_menu_html_atts['option_radio']['data-relation'] 	= '{$option_relation_id}';
		}

		/**
		 * Set Navigation Item
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_set_nav_item($item,$depth){
			is_object($item) ? $this->met_mega_menu_nav_item = $item : false;
			$this->met_mega_menu_nav_item_depth = $depth;
			$this->met_mega_menu_nav_item_data = get_post_meta( $item->ID , '_mmm_options', true );
		}

		/**
		 * Build -> Section
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_build_section($section_id = 0, $section = array()){
			do_action('MMM_set_options',$section_id);

			$section_atts_param = array();
			$section_atts_param = array(
				'html_el' => 'section',
				'data' => array(
					'section_id' => $section_id,
					'section_depth' => $section['depth'],
				)
			);

			if($section['sub'] != false){
				$section_atts_param['data']['parent_section'] 	= $section['sub']['parent_section'];
				$section_atts_param['data']['parent_option'] 	= $section['sub']['parent_option'];
				$section_atts_param['data']['parent_value'] 	= $section['sub']['parent_value'];
			}
			?>

			<div <?php echo apply_filters('MMM_filter_html_atts',$section_atts_param) ?> >
				<div class="met_mega_menu_sections_box_header">
					<span><?php echo $section['title']; ?></span>
					<a class="fa fa-arrow-down"></a>
				</div>

				<div class="met_mega_menu_sections_box_container">
					<?php
					foreach($this->met_mega_menu_options[$section_id] as $met_mega_nav_option){
						echo $this->met_mega_menu_build_option($met_mega_nav_option);
					}
					?>
				</div>
			</div>
		<?php
		}

		/**
		 * Build -> Option
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_build_option($option = array()){
			$output = '';

			$met_mega_nav_option = $option;
			$item = $this->met_mega_menu_nav_item;

			parse_str($this->met_mega_menu_nav_item_data,$met_mega_menu_nav_item_data_arr);

			$option_ID 					= isset($met_mega_nav_option['id']) ? $met_mega_nav_option['id'] : '';
			$option_title 				= isset($met_mega_nav_option['title']) ? $met_mega_nav_option['title'] : '';
			$option_type 				= isset($met_mega_nav_option['type']) ? $met_mega_nav_option['type'] : '';
			$option_value 				= isset($met_mega_menu_nav_item_data_arr[$met_mega_nav_option['id']]) ? $met_mega_menu_nav_item_data_arr[$met_mega_nav_option['id']] : '';
			$option_default 			= isset($met_mega_nav_option['default']) ? $met_mega_nav_option['default'] : '';
			$option_choices 			= isset($met_mega_nav_option['options']) ? $met_mega_nav_option['options'] : '';
			$option_releated_options 	= isset($met_mega_nav_option['releated_options']) ? $met_mega_nav_option['releated_options'] : '';
			$option_has_relation		= (is_array($option_releated_options) ? 'has_relation' : '');
			$option_relation_id			= $option_ID.'-'.$item->ID;

			if($option_value == "") $option_value = $option_default;

			$option_atts_param = array();
			$option_atts_param = array(
				'html_el' => 'option',
				'data' => array(
					'option_type' 			=> $option_type,
					'option_ID' 			=> $option_ID,
					'item_ID' 				=> $item->ID,
					'option_value' 			=> $option_value,
					'option_has_relation' 	=> $option_has_relation
				)
			);

			if($option_type == 'radio'){
				$output .= '<p class="description">';
				foreach($option_choices as $radio_optionKEY => $radio_optionLABEL):
					if($option_has_relation) $option_relation_id = $option_ID.'-'.$item->ID.'-'.$radio_optionKEY;

					$option_atts_param['html_el'] = 'option_radio';
					$option_atts_param['data']['option_relation_id'] = $option_relation_id;
					$option_atts_param['data']['radio_optionKEY'] = $radio_optionKEY;
					$option_atts_param['data']['option_value'] = $radio_optionKEY;

					$checked = '';
					if( $option_value == $radio_optionKEY ){
						$checked 		= "checked";
					}

					$output .= '
					<label for="edit-'.$option_ID.'-'.$item->ID.'-'.$radio_optionKEY.'">
						<input type="radio" '.$checked.' '.apply_filters('MMM_filter_html_atts',$option_atts_param).' /> <span>'.$radio_optionLABEL.'</span><br/>
					</label>
					';

				endforeach;
				$output .= '</p>';
			}

			elseif($option_type == 'checkbox'){
				$option_atts_param['data']['option_relation_id'] = $option_relation_id;
				$checked = '';

				if( $option_value == "1" ){
					$checked 		= "checked";
				}

				$output .= '
				<p class="description">
					<label>
						<input type="checkbox" '.$checked.' '.apply_filters('MMM_filter_html_atts',$option_atts_param).' />
						'.$option_title.'
					</label>
				</p>';
			}

			elseif($option_type == 'text'){
				$output .= '
				<p class="description">
					<label>
						<input type="text" '.apply_filters('MMM_filter_html_atts',$option_atts_param).' />
						<span class="text-input-hint">
							'.$option_title.'
						</span>
					</label>
				</p>';
			}

			elseif($option_type == 'select' OR $option_type == 'select_sidebar'){
				$output .= '<div class="description">';

				if( $option_type == 'select_sidebar' ){
					$output .= '<fieldset>
					<legend>'.$option_title.'</legend>';
				}else{
					$output .= '<label> '.$option_title.'<br />';
				}

				$output .= '<div class="select"><select data-relation="'.$option_relation_id.'" id="edit-'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_select '.(($option_type == 'select_sidebar') ? 'met_mega_menu_select_sidebar' : '').' met_mega_menu_select_'.$option_ID.'-'.$item->ID.' '.$option_has_relation.' met_mega_menu_'.$option_ID.'" name="'.$option_ID . '['. $item->ID .']" >';
				foreach($option_choices as $select_optionKEY => $select_optionLABEL):
					$output .= '<option '.(($option_value==$select_optionKEY) ? 'selected="selected"' : '').' value="'.$select_optionKEY.'">'.$select_optionLABEL.'</option>';
				endforeach;
				$output .= '</select></div>';

				if( $option_type != 'select_sidebar' )
					$output .= '</label>';

				if( $option_type == 'select_sidebar' ){
					$output .= '<br />';

					$output .= '<div class="mmm-button-group">';
					$output .= '<a href="javascript:;" id="button-add-'.$option_ID.'-'.$item->ID.'" rel="'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_add_sidebar_button mmm-button">'.__('Create New Sidebar','met_mega_menu').'</a> ';
					$output .= '<a href="javascript:;" id="button-remove-'.$option_ID.'-'.$item->ID.'" rel="'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_delete_sidebar_button mmm-button">'.__('Delete','met_mega_menu').'</a>';
					$output .= '</div>';

					$output .= '<div class="mmm-alert mmm-sidebar-ajax-alert sidebar-alert-'.$option_ID.'-'.$item->ID.'" style="display:none"></div>';
				}

				if( $option_type != 'select_sidebar' )
					$output .= '</fieldset>';

				$output .= '</div>';
			}

			elseif($option_type == 'note'){
				$output .= '<div class="description">';
				$output .= '<div class="mmm-alert mmm-notice met_mega_menu_'.$option_ID.'">'.$option_title.'</div>';
				$output .= '</div>';
			}

			elseif($option_type == 'category_select'){
				$output .= '<div class="description"><label> '.$option_title.'<br />';

				$taxonomies = get_taxonomies( '' , 'objects'  );

				$del_array = array('post_tag','nav_menu','link_category','post_format','product_type','product_tag','product_shipping_class','shop_order_status','pa_color','dslc_download_cats');
				foreach ( $del_array as $del ){
					if( $taxonomies ){
                        foreach ( $taxonomies as $tax ){
                            if( $del == $tax->name ){ unset($taxonomies[$tax->name]); }
                        }
                    }
				}

				$output .= '<div class="select">';
				$output .= '<select id="edit-'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_select met_mega_menu_select_category" name="'.$option_ID . '['. $item->ID .']" >';
				$output .= '<option value="0">'.__('Choose a Category','met_mega_menu').'</option>';

				if( $taxonomies ){
                    foreach ( $taxonomies as $tax ){
                        $output .= '<optgroup data-taxonomy="'.$tax->name.'" label="'.$tax->label.' ('.get_post_type_object($tax->object_type[0])->labels->singular_name.')">';
                        $args = array(
                            'hide_empty'    => 0,
                            'hierarchical'  => 1,
                            'echo'          => 0,
                            'taxonomy'      => $tax->name,
                            'title_li'      => $tax->name,
                            'style'         => 'none',
                            'walker'        => new MET_Mega_Menu_Admin_Category_Walker( $option_value, $tax->name )
                        );
                        $output .= wp_list_categories($args);
                        $output .= '</optgroup>';
                    }
                }
                
				$output .= '</select>';
				$output .= '</div>';

				//$output .= '<input type="hidden" value="" id="edit-'.$option_ID.'_taxonomy-'.$item->ID.'" class="met_mega_menu_hidden met_mega_menu_'.$option_ID.'_taxonomy" name="'.$option_ID .'_taxonomy'. '['. $item->ID .']" />';
				$output .= '</label></div>';
			}

			elseif($option_type == 'wp_editor'){
				$output .= '<div class="description">';

				$output .= '<fieldset>
				<legend>'.$option_title.'</legend>';

				$output .= '<textarea id="edit-'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_wp_textarea met_mega_menu_wp_textarea_'.$option_ID.'-'.$item->ID.' met_mega_menu_'.$option_ID.'" name="'.$option_ID . '['. $item->ID .']" >'.$option_value.'</textarea><br />';
				$output .= '<a href="#met_mfp_wp_editor" id="button-'.$option_ID.'-'.$item->ID.'" rel="'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_wp_editor_button mmm-button">'.__('Open Advanced Editor','met_mega_menu').'</a>';

				$output .= '</fieldset>';

				$output .= '</div>';
			}

			elseif($option_type == 'fontawesome'){
				$output .= '
				<p class="description">
					<span class="met_mega_menu_fa_preview met_mega_menu_fa_preview_'.$option_ID.'-'.$item->ID.'"><i class="fa '.((empty($option_value)) ? 'fa-times fa-none' : $option_value).'"></i></span>
					<a href="#met_mfp_fa_icon_selector" id="button-'.$option_ID.'-'.$item->ID.'" rel="'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_fa_button mmm_mfp mmm-button">'.$option_title.'</a>
					<input type="hidden" value="'.$option_value.'" id="edit-'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_input_hidden met_mega_menu_'.$option_ID.'" name="'.$option_ID . '['. $item->ID .']" />
				</p><div class="clear"></div>';
			}

			elseif($option_type == 'upload'){
				$output .= '<div class="description">';

				$output .= '<fieldset class="mmm-upload-form">
				<legend>'.$option_title.'</legend>';

				$output .= '
				<span class="met_mega_menu_upload_preview met_mega_menu_upload_preview_'.$option_ID.'-'.$item->ID.'">'.((empty($option_value)) ? '<i class="fa fa-times fa-none"></i>' : '<img src="'.$option_value.'" alt="" />').'</span>
				<input type="text" value="'.$option_value.'" id="edit-'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_upload_input met_mega_menu_'.$option_ID.'" name="'.$option_ID . '['. $item->ID .']" />
				<a href="javascript:;" rel="'.$option_ID.'-'.$item->ID.'" class="met_mega_menu_upload_button mmm-button">'.__('Upload','met_mega_menu').'</a>';

				$output .= '</fieldset>';

				$output .= '</div>';
			}

			if(is_array($option_releated_options)){

				foreach($option_releated_options as $relationID => $releated_options){

					if( count($releated_options) > 0 ){
						$output .= '<div class="met_mega_menu_sub_options met_mega_menu_sub_options_'.$option_ID.'-'.$item->ID.'-'.$relationID.'">';

						$output .= '<div class="met_mega_menu_sub_options_header"><i class="fa fa-arrow-right"></i> <span>'.$option_value.'</span></div>';
						$output .= '<div class="met_mega_menu_sub_options_container">';

						foreach($releated_options as $releated_option){
							$output .= $this->met_mega_menu_build_option($releated_option);
						}

						$output .= '</div>';

						$output .= '</div>';
					}

				}

			}

			return $output;
		}

		/**
		 * Build -> Item Options (Options for WP Menu Items)
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_build_item_options($item = array(),$depth){
			do_action('MMM_set_sections');
			do_action('MMM_set_nav_item',$item,$depth);

			parse_str($this->met_mega_menu_nav_item_data,$met_mega_menu_nav_item_data_arr);

			if( isset( $_POST['save_menu'] ) ){

				$count = 0;
				foreach( $_POST as $key => $arr ){
					$count+= count( $arr );
				}

				echo '<!-- post count: '.$count.'-->';
			}
			?>

			<!-- **** MET Creative | Mega Menu Options [START] **** -->
			<input type="hidden" class="met_mega_menu_item_data" name="mmm-menu-item-data[<?php echo $item->ID ?>]" value="<?php echo $this->met_mega_menu_nav_item_data ?>">
			<div class="met_mega_menu_sections_wrapper">
				<?php
				foreach($this->met_mega_menu_sections as $met_mega_nav_sectionID => $met_mega_nav_section):
					$this->met_mega_menu_build_section($met_mega_nav_sectionID,$met_mega_nav_section);
				endforeach;
				?>
			</div>
			<!-- **** MET Creative | Mega Menu Options [END] **** -->
		<?php
		}

		/**
		 * Custom sidebars for menu items.
		 *
		 * @since 1.0.0
		 */
		function met_mega_menu_sidebars_init(){
			//delete_option($this->met_mega_menu_sidebars_option_name);
			$mmm_sidebar_option = get_option( $this->met_mega_menu_sidebars_option_name );

			if ( $mmm_sidebar_option == false ) {

				//No sidebar found, create default one.
				$deprecated = null;
				$autoload = 'no';
				add_option( $this->met_mega_menu_sidebars_option_name, $this->met_mega_menu_sidebars_option_default, $deprecated, $autoload );

			}else{
				$this->met_mega_menu_sidebars = $mmm_sidebar_option;

				if( count($this->met_mega_menu_sidebars) ){
					foreach($this->met_mega_menu_sidebars as $mmm_sidebar_itemID => $mmm_sidebar_itemName){
						register_sidebar(array(
							'name'          => ':[MC-MM] '.$mmm_sidebar_itemName,
							'id'            => 'mc-mm-'.$mmm_sidebar_itemID,
							'description'   => 'This sidebar dynamicly created on MC Mega Menu.',
							'class'         => '',
							'before_widget' => '<li id="%1$s" class="mmm-widget %2$s">',
							'after_widget'  => '</li><li class="clearfix"></li>',
							'before_title'  => '<h2 class="mmm-widget-title">',
							'after_title'   => '</h2>' ));
					}
				}
			}
		}
		/**
		 * Filters -> HTML Elements Atts
		 *
		 * @since 1.0.0
		 *
		 * @param array $params
		 */
		function met_mega_menu_FILTER_html_atts($params = array()){
			do_action('MMM_set_html_atts');
			$atts = $this->met_mega_menu_html_atts[$params['html_el']];

			if( is_array($params['data']) ) extract($params['data']);

			$item_atts_result = array();
			if(count($atts)){
				foreach ( $atts as $attr => $value ) {
					if(is_array($value)) $value = implode(' ',$value);


					if ( ! empty( $value ) ) {
						$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );

						/* Replace Vars (if exist) */
						preg_match_all('~\{\$(.*?)\}~si',$value,$matches);
						if ( isset($matches[1])) {
							$r = compact($matches[1]);
							foreach ( $r as $var => $val ) {
								$value = str_replace('{$'.$var.'}',$val,$value);
							}
						}


						preg_match('~\{\$(.*?)\}~si',$value,$value_check);
						if ( !isset($value_check[0]) ) {
							$item_atts_result[] = $attr . '="' . $value . '"';
						}


					}

				}
				return implode(' ',$item_atts_result);
			}else{
				return;
			}
		}

		function met_mega_menu_admin_init(){
			add_action('admin_print_styles-nav-menus.php', array($this, 'met_mega_menu_admin_enqueue_styles'));
			add_action('admin_print_styles-nav-menus.php', array($this, 'met_mega_menu_admin_enqueue_scripts'));

			add_filter('wp_edit_nav_menu_walker', array($this, 'met_mega_menu_admin_walker'), 3000);
			add_action('wp_update_nav_menu_item', array($this, 'met_mega_menu_admin_update_menu'), 101, 3);

			add_action('admin_footer', array($this, 'met_mega_menu_admin_mfp'));
		}

		function met_mega_menu_admin_enqueue_styles(){
			wp_enqueue_style('mmm_admin_fontawesome', MMM_DIR_URL.'css/fontawesome/style.css', array(), MMM_VERSION);
			wp_enqueue_style('mmm_admin_magnific_popup', MMM_DIR_URL.'css/magnific-popup.css', array(), MMM_VERSION);

			wp_enqueue_style('mmm_admin_css', MMM_DIR_URL.'css/mmm-admin.css', array(), MMM_VERSION);
		}

		function met_mega_menu_admin_enqueue_scripts(){
			wp_enqueue_media();

			wp_enqueue_script('mmm_admin_magnific_popup', MMM_DIR_URL.'js/magnific-popup.inline.min.js',  array(), MMM_VERSION, true );

			wp_enqueue_script('mmm_admin_js', MMM_DIR_URL.'js/mmm-admin.js',  array('jquery', 'media-upload', 'jquery-ui-core', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-sortable' ), MMM_VERSION, true );

			// @todo: i18n strings for prompts.
			wp_localize_script('mmm_admin_js', 'mmm_ajax', array(
					'ajaxurl'			=> admin_url( 'admin-ajax.php' ),
					'mmmAjaxNonce' 		=> wp_create_nonce( 'mmm-ajax-nonce' ),
				)
			);
		}

		function met_mega_menu_admin_ajax(){
			$nonce = $_POST['mmmAjaxNonce'];

			if ( ! wp_verify_nonce( $nonce, 'mmm-ajax-nonce' ) )
				die ( 'Nope!');

			if ( current_user_can( 'edit_theme_options' ) ) {
				if( $_POST['do_action'] == 'add' ){

					$ajax_response_new_sidebar_name = $_POST['sidebar_name'];

					//i need to check sidebar name, if exist add suffix. markup: " Sidebar Name ($increment) "
					$increment = '';
					if( is_array($this->met_mega_menu_sidebars) ){
						foreach( $this->met_mega_menu_sidebars as $sidebarID => $sidebarTitle ){
							while( $sidebarID == sanitize_title($ajax_response_new_sidebar_name.' ('.$increment.')') ) {
								$increment++;
							}
						}
					}

					if($increment != '') $ajax_response_new_sidebar_name .= ' ('.$increment.')';

					$mmm_new_sidebar = array(sanitize_title($ajax_response_new_sidebar_name) => $ajax_response_new_sidebar_name);

					//update mc mega menu sidebars, add new one.
					update_option($this->met_mega_menu_sidebars_option_name, array_merge((array)$this->met_mega_menu_sidebars, (array)$mmm_new_sidebar));

					//prepare json response, i will append and make selected new sidebar. (mmm-admin.js)
					$json_arr = array('old' => $this->met_mega_menu_sidebars, 'new' => $mmm_new_sidebar, 'status' => 'ok');

				}elseif( $_POST['do_action'] == 'remove' ){
					$sidebarID = $_POST['sidebarID'];

					if( isset($this->met_mega_menu_sidebars[$sidebarID]) ){

						//remove $sidebarID
						unset($this->met_mega_menu_sidebars[$sidebarID]);

						//update mc mega menu sidebars
						update_option($this->met_mega_menu_sidebars_option_name, (array)$this->met_mega_menu_sidebars);

						$json_arr = array('status' => 'ok','id' => $sidebarID);
					}else{
						$json_arr = array('status' => 'id_not_found','id' => $sidebarID);
					}
				}

				if( !isset($_POST['do_action']) ){
					$json_arr = array('status' => 'no_action');
				}

				header( "Content-Type: application/json" );
				$json_response = json_encode( $json_arr );
				echo $json_response;

			}

			exit;
		}

		function met_mega_menu_admin_mfp(){
			$screen = get_current_screen();
			if( $screen->id != 'nav-menus' ) return;

			/**
			 * Magnific Popup -> WordPress Editor
			 *
			 * @since 1.0.0
			 */

			echo '<div id="met_mfp_wp_editor_wrapper">';
			echo '<div class="mfp-bg">';
			echo '</div>';

			echo '<div id="met_mfp_wp_editor">';
			echo '<div class="met_mfp_header">
				<span>'.__('WordPress Editor').'</span>
				<a title="'.__('Update','met_mega_menu').'" class="met_mfp_wp_editor_update fa fa-check"></a>
				<a title="'.__('Close','met_mega_menu').'" class="met_mfp_wp_editor_cancel fa fa-times"></a>
			</div>';

			echo '<div id="met_mfp_wp_editor_content">';
			wp_editor( '', 'met_wp_editor', array('wpautop' => false) );
			echo '</div>';

			echo '<input type="hidden" class="met_wp_rel" value="" />';
			echo '</div>';


			echo '</div>';


			/**
			 * Magnific Popup -> Font Awesome
			 *
			 * @since 1.0.0
			 */
			$pattern = '/\.(fa-(?:\w+(?:-)?)+):before{content:/';
			$subject = file_get_contents(MMM_DIR_URL. 'css/fontawesome/style.css');

			preg_match_all($pattern, $subject, $matches, PREG_SET_ORDER);

			$fontAwesome = array();

			foreach($matches as $match){
				$fontAwesome[] = $match[1];
			}

			echo '<div id="met_mfp_fa_icon_selector" class="mfp-hide">';
			echo '<div class="met_mfp_header"><span>'.__('FontAwesome Icons').'</span> <a title="'.__('Close','met_mega_menu').'" class="met_mfp_fa_cancel fa fa-times"></a></div>';

			echo '<div id="met_mfp_fa_icon_list">';
			foreach ( $fontAwesome as $icon ){
				echo '<span class="mmm-button" data-icon="'.$icon.'"><i class="fa '.$icon.'"></i></span>';
			}
			echo '</div>';

			echo '<br />';
			echo '';
			echo '<input type="hidden" class="met_fa_rel" value="" />';

			echo '</div>';
		}

		function met_mega_menu_admin_walker($class){
			return 'MET_Mega_Menu_Admin_Walker';
		}

		function met_mega_menu_admin_update_menu( $menu_id, $menu_item_db_id, $args ){
			$mmm_item_data = ( isset($_POST['mmm-menu-item-data'][$menu_item_db_id]) ) ? $_POST['mmm-menu-item-data'][$menu_item_db_id] : '';
			update_post_meta( $menu_item_db_id, '_mmm_options', $mmm_item_data );
		}

		function met_mega_menu_admin_add_menu_item(){

			check_ajax_referer( 'add-menu_item', 'menu-settings-column-nonce' );

			if ( ! current_user_can( 'edit_theme_options' ) )
				wp_die('-1');

			require_once ABSPATH . 'wp-admin/includes/nav-menu.php';

			// For performance reasons, we omit some object properties from the checklist.
			// The following is a hacky way to restore them when adding non-custom items.

			$menu_items_data = array();
			foreach ( (array) $_POST['menu-item'] as $menu_item_data ) {
				if (
					! empty( $menu_item_data['menu-item-type'] ) &&
					'custom' != $menu_item_data['menu-item-type'] &&
					! empty( $menu_item_data['menu-item-object-id'] )
				) {
					switch( $menu_item_data['menu-item-type'] ) {
						case 'post_type' :
							$_object = get_post( $menu_item_data['menu-item-object-id'] );
							break;

						case 'taxonomy' :
							$_object = get_term( $menu_item_data['menu-item-object-id'], $menu_item_data['menu-item-object'] );
							break;
					}

					$_menu_items = array_map( 'wp_setup_nav_menu_item', array( $_object ) );
					$_menu_item = array_shift( $_menu_items );

					// Restore the missing menu item properties
					$menu_item_data['menu-item-description'] = $_menu_item->description;
				}

				$menu_items_data[] = $menu_item_data;
			}

			$item_ids = wp_save_nav_menu_items( 0, $menu_items_data );
			if ( is_wp_error( $item_ids ) )
				wp_die( 0 );

			$menu_items = array();

			foreach ( (array) $item_ids as $menu_item_id ) {
				$menu_obj = get_post( $menu_item_id );
				if ( ! empty( $menu_obj->ID ) ) {
					$menu_obj = wp_setup_nav_menu_item( $menu_obj );
					$menu_obj->label = $menu_obj->title; // don't show "(pending)" in ajax-added items
					$menu_items[] = $menu_obj;
				}
			}

			if ( ! empty( $menu_items ) ) {
				$args = array(
					'after' => '',
					'before' => '',
					'link_after' => '',
					'link_before' => '',
					'walker' =>	new MET_Mega_Menu_Admin_Walker,
				);
				echo trim( walk_nav_menu_tree( $menu_items, 0, (object) $args ) );
			}
			wp_die();
		}
	}

}