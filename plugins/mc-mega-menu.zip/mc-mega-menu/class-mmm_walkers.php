<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( !class_exists( 'MET_Mega_Menu_Admin_Walker' ) ){
	class MET_Mega_Menu_Admin_Walker extends Walker_Nav_Menu{

		/**
		 * @see Walker_Nav_Menu::start_lvl()
		 * @since 3.0.0
		 *
		 * @param string $output Passed by reference.
		 * @param int $depth Depth of page.
		 */
		function start_lvl(&$output, $depth = 0, $args = array() ) {}

		/**
		 * @see Walker_Nav_Menu::end_lvl()
		 * @since 3.0.0
		 *
		 * @param string $output Passed by reference.
		 * @param int $depth Depth of page.
		 */
		function end_lvl(&$output, $depth = 0, $args = array() ) {}

		/**
		 * @see Walker::start_el()
		 * @since 3.0.0
		 *
		 * @param string $output Passed by reference. Used to append additional content.
		 * @param object $item Menu item data object.
		 * @param int $depth Depth of menu item. Used for padding.
		 * @param int $current_page Menu item ID.
		 * @param object $args
		 */
		function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
			global $_wp_nav_menu_max_depth;
			$_wp_nav_menu_max_depth = $depth > $_wp_nav_menu_max_depth ? $depth : $_wp_nav_menu_max_depth;

			$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

			ob_start();
			$item_id = esc_attr( $item->ID );
			$removed_args = array(
				'action',
				'customlink-tab',
				'edit-menu-item',
				'menu-item',
				'page-tab',
				'_wpnonce',
			);

			$original_title = '';
			if ( 'taxonomy' == $item->type ) {
				$original_title = get_term_field( 'name', $item->object_id, $item->object, 'raw' );
				if ( is_wp_error( $original_title ) )
					$original_title = false;
			} elseif ( 'post_type' == $item->type ) {
				$original_object = get_post( $item->object_id );
				$original_title = $original_object->post_title;
			}

			$classes = array(
				'menu-item menu-item-depth-' . $depth,
				'menu-item-' . esc_attr( $item->object ),
				'menu-item-edit-' . ( ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? 'active' : 'inactive'),
			);

			$title = $item->title;

			if ( ! empty( $item->_invalid ) ) {
				$classes[] = 'menu-item-invalid';
				/* translators: %s: title of menu item which is invalid */
				$title = sprintf( __( '%s (Invalid)' ), $item->title );
			} elseif ( isset( $item->post_status ) && 'draft' == $item->post_status ) {
				$classes[] = 'pending';
				/* translators: %s: title of menu item in draft status */
				$title = sprintf( __('%s (Pending)'), $item->title );
			}

			$title = ( ! isset( $item->label ) || '' == $item->label ) ? $title : $item->label;

			$submenu_text = '';
			if ( 0 == $depth )
				$submenu_text = 'style="display: none;"';

			?>

		<li id="menu-item-<?php echo $item_id; ?>" class="<?php echo implode(' ', $classes ); ?>">
			<dl class="menu-item-bar">
				<dt class="menu-item-handle">
					<span class="item-title"><span class="menu-item-title"><?php echo esc_html( $title ); ?></span> <span class="is-submenu" <?php echo $submenu_text; ?>><?php _e( 'sub item' ); ?></span></span>
					<span class="item-controls">
						<span class="item-type"><?php echo esc_html( $item->type_label ); ?></span>
						<span class="item-order hide-if-js">
							<a href="<?php
							echo wp_nonce_url(
								add_query_arg(
									array(
										'action' => 'move-up-menu-item',
										'menu-item' => $item_id,
									),
									remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
								),
								'move-menu_item'
							);
							?>" class="item-move-up"><abbr title="<?php esc_attr_e('Move up'); ?>">&#8593;</abbr></a>
							|
							<a href="<?php
							echo wp_nonce_url(
								add_query_arg(
									array(
										'action' => 'move-down-menu-item',
										'menu-item' => $item_id,
									),
									remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
								),
								'move-menu_item'
							);
							?>" class="item-move-down"><abbr title="<?php esc_attr_e('Move down'); ?>">&#8595;</abbr></a>
						</span>
						<a class="item-edit" id="edit-<?php echo $item_id; ?>" title="<?php esc_attr_e('Edit Menu Item'); ?>" href="<?php
						echo ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? admin_url( 'nav-menus.php' ) : add_query_arg( 'edit-menu-item', $item_id, remove_query_arg( $removed_args, admin_url( 'nav-menus.php#menu-item-settings-' . $item_id ) ) );
						?>"><?php _e( 'Edit Menu Item' ); ?></a>
					</span>
				</dt>
			</dl>

			<div class="menu-item-settings" id="menu-item-settings-<?php echo $item_id; ?>">
				<?php if( 'custom' == $item->type ) : ?>
					<p class="field-url description description-wide">
						<label for="edit-menu-item-url-<?php echo $item_id; ?>">
							<?php _e( 'URL' ); ?><br />
							<input type="text" id="edit-menu-item-url-<?php echo $item_id; ?>" class="widefat code edit-menu-item-url" name="menu-item-url[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->url ); ?>" />
						</label>
					</p>
				<?php endif; ?>
				<p class="description description-thin">
					<label for="edit-menu-item-title-<?php echo $item_id; ?>">
						<?php _e( 'Navigation Label' ); ?><br />
						<input type="text" id="edit-menu-item-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-title" name="menu-item-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->title ); ?>" />
					</label>
				</p>
				<p class="description description-thin">
					<label for="edit-menu-item-attr-title-<?php echo $item_id; ?>">
						<?php _e( 'Title Attribute' ); ?><br />
						<input type="text" id="edit-menu-item-attr-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-attr-title" name="menu-item-attr-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->post_excerpt ); ?>" />
					</label>
				</p>
				<p class="field-link-target description">
					<label for="edit-menu-item-target-<?php echo $item_id; ?>">
						<input type="checkbox" id="edit-menu-item-target-<?php echo $item_id; ?>" value="_blank" name="menu-item-target[<?php echo $item_id; ?>]"<?php checked( $item->target, '_blank' ); ?> />
						<?php _e( 'Open link in a new window/tab' ); ?>
					</label>
				</p>
				<p class="field-css-classes description description-thin">
					<label for="edit-menu-item-classes-<?php echo $item_id; ?>">
						<?php _e( 'CSS Classes (optional)' ); ?><br />
						<input type="text" id="edit-menu-item-classes-<?php echo $item_id; ?>" class="widefat code edit-menu-item-classes" name="menu-item-classes[<?php echo $item_id; ?>]" value="<?php echo esc_attr( implode(' ', $item->classes ) ); ?>" />
					</label>
				</p>
				<p class="field-xfn description description-thin">
					<label for="edit-menu-item-xfn-<?php echo $item_id; ?>">
						<?php _e( 'Link Relationship (XFN)' ); ?><br />
						<input type="text" id="edit-menu-item-xfn-<?php echo $item_id; ?>" class="widefat code edit-menu-item-xfn" name="menu-item-xfn[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->xfn ); ?>" />
					</label>
				</p>
				<p class="field-description description description-wide">
					<label for="edit-menu-item-description-<?php echo $item_id; ?>">
						<?php _e( 'Description' ); ?><br />
						<textarea id="edit-menu-item-description-<?php echo $item_id; ?>" class="widefat edit-menu-item-description" rows="3" cols="20" name="menu-item-description[<?php echo $item_id; ?>]"><?php echo esc_html( $item->description ); // textarea_escaped ?></textarea>
						<span class="description"><?php _e('The description will be displayed in the menu if the current theme supports it.'); ?></span>
					</label>
				</p>

				<p class="field-move hide-if-no-js description description-wide">
					<label>
						<span><?php _e( 'Move' ); ?></span>
						<a href="#" class="menus-move-up"><?php _e( 'Up one' ); ?></a>
						<a href="#" class="menus-move-down"><?php _e( 'Down one' ); ?></a>
						<a href="#" class="menus-move-left"></a>
						<a href="#" class="menus-move-right"></a>
						<a href="#" class="menus-move-top"><?php _e( 'To the top' ); ?></a>
					</label>
				</p>

				<?php /* MC Mega Menu */ ?>
				<?php do_action('MMM_build_item_options', $item, $depth) ?>
				<?php /* MC Mega Menu */ ?>

				<div class="menu-item-actions description-wide submitbox">
					<?php if( 'custom' != $item->type && $original_title !== false ) : ?>
						<p class="link-to-original">
							<?php printf( __('Original: %s'), '<a href="' . esc_attr( $item->url ) . '">' . esc_html( $original_title ) . '</a>' ); ?>
						</p>
					<?php endif; ?>
					<a class="item-delete submitdelete deletion" id="delete-<?php echo $item_id; ?>" href="<?php
					echo wp_nonce_url(
						add_query_arg(
							array(
								'action' => 'delete-menu-item',
								'menu-item' => $item_id,
							),
							admin_url( 'nav-menus.php' )
						),
						'delete-menu_item_' . $item_id
					); ?>"><?php _e( 'Remove' ); ?></a> <span class="meta-sep hide-if-no-js"> | </span> <a class="item-cancel submitcancel hide-if-no-js" id="cancel-<?php echo $item_id; ?>" href="<?php echo esc_url( add_query_arg( array( 'edit-menu-item' => $item_id, 'cancel' => time() ), admin_url( 'nav-menus.php' ) ) );
					?>#menu-item-settings-<?php echo $item_id; ?>"><?php _e('Cancel'); ?></a>
				</div>

				<input class="menu-item-data-db-id" type="hidden" name="menu-item-db-id[<?php echo $item_id; ?>]" value="<?php echo $item_id; ?>" />
				<input class="menu-item-data-object-id" type="hidden" name="menu-item-object-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object_id ); ?>" />
				<input class="menu-item-data-object" type="hidden" name="menu-item-object[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object ); ?>" />
				<input class="menu-item-data-parent-id" type="hidden" name="menu-item-parent-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_item_parent ); ?>" />
				<input class="menu-item-data-position" type="hidden" name="menu-item-position[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_order ); ?>" />
				<input class="menu-item-data-type" type="hidden" name="menu-item-type[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->type ); ?>" />
			</div><!-- .menu-item-settings-->
			<ul class="menu-item-transport"></ul>
			<?php
			$output .= ob_get_clean();
		}
	}
}

if( !class_exists('MET_Mega_Menu_Admin_Category_Walker') ){
	class MET_Mega_Menu_Admin_Category_Walker extends Walker_Category {

		public $selected_cat;
		public $selected_tax;

		function __construct( $selected_cat = 0, $selected_tax = null ) {
			$this->selected_cat = $selected_cat;
			$this->selected_tax = $selected_tax;
		}

		var $tree_type = 'category';

		var $db_fields = array ('parent' => 'parent', 'id' => 'term_id');

		function start_lvl( &$output, $depth = 0, $args = array() ) {}

		function end_lvl( &$output, $depth = 0, $args = array() ) {}

		function start_el( &$output, $category, $depth = 0, $args = array(), $id = 0 ) {
			extract($args);

			$option_value = '';

			$cat_name = esc_attr( $category->name );
			$cat_name = apply_filters( 'list_cats', $cat_name, $category );

			$indent = '';
			if ( $category->category_parent != 0 ) {
				$indent = '&nbsp;&nbsp;&nbsp;&nbsp;';
			}

			$option_value = $category->cat_ID.'-'.$this->selected_tax;

			$op  = '<option value="'.$option_value.'" '.($this->selected_cat == $option_value ? ' selected="selected" ' : '').' >';
			$op .= $indent.$cat_name . '</option>';

			$output .= $op;
		}

		function end_el( &$output, $page, $depth = 0, $args = array() ) {
			$output .= "";
		}
	}
}

if( !class_exists( 'MET_Mega_Menu_Walker' ) ){
	class MET_Mega_Menu_Walker {

		var $mmm_key = '_mmm_options';

		var $mmm_item = 0;
		var $mmm_item_icon = array();
		var $mmm_item_depth = array();
		var $mmm_item_parent_type = null;
		var $mmm_item_parent_id = null;
		var $mmm_item_data = array();

		var $mmm_spec_menu_type_html_markup = array('tabbed_posts','posts');
		var $mmm_html_markup = array();
		var $mmm_html_markup_values = array();

		var $mmm_nav_item_class = array();

		var $tabbed_post_items = array();

		public function __construct() {

			$this->mmm_html_markup = array(
				'start_el' => array(
					'li' => '{$indent}<li {$item_atts}>',
					'a'  => '{$args.before}<a {$link_atts}>{$args.link_before}{$the_title}{$args.link_after}</a>{$args.after}'
				),
				'end_el' => array(
					'li'		=> '{$link_after}</li><!-- #menu-item-{$menu_ID} -->'."\n",
				),
				'start_lvl' => array(
					'default' 		=>	"\n" .'{$indent}<ul {$item_atts}>'. "\n",
					'mega'  		=>	'',
					'posts'  		=>	'',
					'tabbed_posts' 	=>	"\n" . "\t" .'<ul {$item_atts}>'.
						"\n" . "\t" ."\t" .'<li class="clearfix">'.
						"\n" . "\t" ."\t" .'<ul class="met_megamenu_tabbed_post_cats">'."\n",
					'advanced'  	=> '',
					'search'  		=> '',
				),
				'end_lvl' => array(
					'default' 		=>	'{$indent}</ul>'."\n",
					'mega'  		=>	'',
					'posts'  		=>	'',
					'tabbed_posts' 	=>	"\t" . "\t" .'</ul><!-- .met_megamenu_tabbed_post_cats -->'.'{$tab_category_output}'.
						"\n" . "\t" ."\t" .'</li><!-- .clearfix  -->'.
						"\n" . "\t" ."\t" .'<li class="mmm-v-divider"></li></ul><!-- .met_megamenu_tabbed_posts_wrapper  -->',
					'advanced'  	=> '',
					'search'  		=> '',
				),
				'icon'	=> array(
					'upload'	=> '<img {$atts} />',
					'fa'		=> '<i {$atts}></i>',
					'text'		=> '<i {$atts}>{$icon_text}</i>',
				)
			);

			add_filter( 'wp_setup_nav_menu_item', array( $this, 'met_mega_menu_setup_nav_item' ) );

			add_filter( 'the_title', array( $this, 'met_mega_menu_the_title' ), 10, 2 );

			add_filter( 'mmm_start_el', array( $this, 'met_mega_menu_start_el' ) );
			add_filter( 'mmm_end_el', array( $this, 'met_mega_menu_end_el' ) );
			add_filter( 'mmm_start_lvl', array( $this, 'met_mega_menu_start_lvl' ) );
			add_filter( 'mmm_end_lvl', array( $this, 'met_mega_menu_end_lvl' ) );

			add_filter( 'mmm_parse_html_markup', array( $this, 'met_mega_menu_parse_html_markup' ), 10, 3 );
			add_filter( 'mmm_nav_atts', array( $this, 'met_mega_menu_nav_atts' ), 10, 3 );
		}

		function met_mega_menu_setup_nav_item( $menu_item ) {

			parse_str(get_post_meta( $menu_item->ID, $this->mmm_key, true), $mmm_data);
			if( count($mmm_data) == 0 ) $mmm_data = false;

			$menu_item->mmm_data = $mmm_data;

			return $menu_item;

		}

		function met_mega_menu_the_title( $title, $id ) {
			$output = '';

			if( isset($this->mmm_item_data[$id]) ){ //we need to filter only mega menu titles.
				if( isset($this->mmm_item_icon[$id]) AND met_option('mmm_top_level_icon_position') == 'left' ){
					$output .= $this->mmm_item_icon[$id];
				}

				$output .= '<span class="met-menu-item-label">';
				if( isset($this->mmm_item_depth[$id]) AND $this->mmm_item_depth[$id] == 0 AND !empty($title) ){
					$output .= '<span>';
					$output .= $title;
					$output .= '</span>';
				}else{
					$output .= $title;
				}

				if(
					( isset($this->mmm_item_depth[$id]) AND $this->mmm_item_depth[$id] === 0 AND met_option('primary_nav_desc_status') ) OR
					( isset($this->mmm_item_depth[$id]) AND $this->mmm_item_depth[$id] >= 1 AND met_option('primary_nav_dropdown_desc_status') )
				){
					if( isset($this->mmm_item->description) AND !empty($this->mmm_item->description) ){
						$output .= '<small class="met-menu-item-desc">';
						$output .= $this->mmm_item->description;
						$output .= '</small>';
					}
				}

				$output .= '</span>'; //.met-menu-item-label

				if( isset($this->mmm_item_icon[$id]) AND met_option('mmm_top_level_icon_position') == 'right' ){
					$output .= $this->mmm_item_icon[$id];
				}
			}else{
				$output = $title; //its not mega menu item, return original title.
			}

			return $output;
		}

		function met_mega_menu_parse_html_markup( $markup_id, $el_id, $markup_values ) {

			$markup = $this->mmm_html_markup[$markup_id][$el_id];

			$keys = $values = array();
			foreach ($markup_values as $key => $value) {
				if( is_array($value) ){
					foreach($value as $sub_key => $sub_value){
						$keys[] = '{$'.$key.'.'.$sub_key.'}';
						$values[] = $sub_value;
					}
				}else{
					$keys[] = '{$'.$key.'}';
					$values[] = $value;
				}
			}

			return str_replace($keys, $values, $markup);

		}

		function met_mega_menu_nav_atts($atts = array(), $doImplode = false, $implodeGlue = ''){

			if(count($atts)){
				foreach ( $atts as $attr => $value ) {
					if(is_array($value)) $value = implode(' ',$value);

					if ( ! empty( $value ) ) {
						$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
						$item_atts_result[] = $attr . '="' . $value . '"';
					}
				}
				return ($doImplode) ? implode($implodeGlue,$item_atts_result) : $item_atts_result;
			}else{
				return;
			}
		}

		function met_mega_menu_start_el( $el_data = array() ) {
			$item_atts = $link_atts = $mmm_item_icon_atts = array();
			$final_output = $mega_output = $html_output = $divider_output = null;
			$item_has_widget = $item_has_html = $item_has_divider = false;

			$menu_item 		= $el_data['item'];
			$menu_depth		= $el_data['depth'];
			$menu_args		= $el_data['args'];

			$this->mmm_item								= $menu_item;
			$this->mmm_item_depth[$menu_item->ID]		= $menu_depth;
			$this->mmm_item_data[$menu_item->ID]		= $menu_item->mmm_data;

			$mmm_item_icon_atts_class = 'met-menu-icon';


			if( $menu_depth === 0 ){
				$this->mmm_item_parent_type = $menu_item->mmm_data['menu_type'];
				$this->mmm_item_parent_id = $menu_item->ID;

				/*
				 * Prepare Menu Item "Default" Icon Output (Top Level)
				 * */
				$mmm_top_level_default_icon = met_option('mmm_top_level_icon_default');
				if( !empty($mmm_top_level_default_icon) ){
					$mmm_item_icon_atts['class'] = $mmm_item_icon_atts_class.' mmm-icon-default fa '.$mmm_top_level_default_icon;

					$this->mmm_item_icon[$menu_item->ID]	= apply_filters('mmm_parse_html_markup', 'icon', 'fa', array(
						'atts' => apply_filters('mmm_nav_atts', $mmm_item_icon_atts, true, ' ')
					));
				}
			}

			/*
			 * Prepare Menu Item "Default" Icon Output (Sub Levels)
			 * */
			if( $menu_depth >= 1 ){
				$mmm_sub_level_icon_default = met_option('mmm_sub_level_icon_default');
				if( !empty($mmm_sub_level_icon_default) ){
					$mmm_item_icon_atts['class'][] = $mmm_item_icon_atts_class.' mmm-icon-default fa '.$mmm_sub_level_icon_default;

					$this->mmm_item_icon[$menu_item->ID]	= apply_filters('mmm_parse_html_markup', 'icon', 'fa', array(
						'atts' => apply_filters('mmm_nav_atts', $mmm_item_icon_atts, true, ' ')
					));
				}
			}

			/*
			 * Prepare Menu Item "Custom" Icon Output (All Levels) (Overwrite default)
			 * */
			if( $menu_item->mmm_data['icon_type'] == "upload" ){
				if( !empty($menu_item->mmm_data['icon_image']) ){
					$mmm_item_icon_atts['src'] 		= $menu_item->mmm_data['icon_image'];
					$mmm_item_icon_atts['class'] 	= $mmm_item_icon_atts_class;

					$this->mmm_item_icon[$menu_item->ID]	= apply_filters('mmm_parse_html_markup', 'icon', 'upload', array(
						'atts' => apply_filters('mmm_nav_atts', $mmm_item_icon_atts, true, ' ')
					));
				}
			}elseif( $menu_item->mmm_data['icon_type'] == "fa" ){
				if( !empty($menu_item->mmm_data['icon_fa']) ){
					$mmm_item_icon_atts['class'] = $mmm_item_icon_atts_class.' fa '.$menu_item->mmm_data['icon_fa'];

					if( !empty($menu_item->mmm_data['icon_fa_color']) ){
						$mmm_item_icon_atts['style'] = 'color: '.$menu_item->mmm_data['icon_fa_color'];
					}

					$this->mmm_item_icon[$menu_item->ID]	= apply_filters('mmm_parse_html_markup', 'icon', 'fa', array(
						'atts' => apply_filters('mmm_nav_atts', $mmm_item_icon_atts, true, ' ')
					));
				}
			}elseif( $menu_item->mmm_data['icon_type'] == "text" ){
				if( !empty($menu_item->mmm_data['icon_text']) ){
					$mmm_item_icon_atts['class'] = $mmm_item_icon_atts_class.' mmm-text-icon';

					if( !empty($menu_item->mmm_data['icon_text_color']) ){
						$mmm_item_icon_atts['style'] = 'color: '.$menu_item->mmm_data['icon_text_color'];
					}

					$this->mmm_item_icon[$menu_item->ID]	= apply_filters('mmm_parse_html_markup', 'icon', 'text', array(
						'atts' => apply_filters('mmm_nav_atts', $mmm_item_icon_atts, true, ' '),
						'icon_text' => $menu_item->mmm_data['icon_text']
					));
				}
			}

			/*
			 * Icons visibility for hightlight labels.
			 * */
			if( (isset($menu_item->mmm_data['highlight_label']) AND $menu_item->mmm_data['highlight_label'] == 1) AND met_option('mmm_sub_level_highlight_icon_disable') == true ){
				$this->mmm_item_icon[$menu_item->ID] = '';
			}

			// Display Options -> Disable Link
			if( isset($menu_item->mmm_data['disable_link']) AND $menu_item->mmm_data['disable_link'] == 1 ){
				$item_atts['class'][] = 'menu-item-without-url';
			}else{
				$link_atts['href']   = ! empty( $menu_item->url )        ? $menu_item->url        : '';
			}

			// Display Options -> Disable Label
			if( isset($menu_item->mmm_data['disable_label']) AND $menu_item->mmm_data['disable_label'] == 1 ){
				$item_atts['class'][] = 'menu-item-without-label';
				$menu_item_title = '';
			}else{
				$menu_item_title = $menu_item->title;
			}

			// Mega Menu Options (Column) -> Divider
			if( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'divider' AND $menu_depth == 1 ){
				$item_atts['class'][] = 'menu-item-is-divider';
			}

			$item_atts['class'][] = 'mmm-icon-align-'.met_option('mmm_top_level_icon_position');

			/*
			 * Link Atts (<a>)
			 * */
			if( $menu_depth === 0 ) $link_atts['class'][] = 'met_vcenter';
			if( isset($menu_item->mmm_data['highlight_label']) AND $menu_item->mmm_data['highlight_label'] == 1 ) $link_atts['class'][] = 'mmm_highlight_label';

			$link_atts['class'][] = 'menu-link';
			$link_atts['title']  = ! empty( $menu_item->attr_title ) ? $menu_item->attr_title : '';
			$link_atts['target'] = ! empty( $menu_item->target )     ? $menu_item->target     : '';
			$link_atts['rel']    = ! empty( $menu_item->xfn )        ? $menu_item->xfn        : '';

			$link_atts = apply_filters('nav_menu_link_attributes', $link_atts, $menu_item, $menu_args);
			$link_atts = apply_filters('mmm_nav_atts', $link_atts, true, ' ');

			/*
			 * Item Atts (<li>)
			 * */
			$indent = ( $menu_depth ) ? str_repeat( "\t", $menu_depth ) : '';

			$item_atts_id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $menu_item->ID, $menu_item, $menu_args );
			$item_atts['id'] = $item_atts_id ? esc_attr( $item_atts_id ) : '';

			$item_atts['class'][] = 'menu-item-' . $menu_item->ID;

			$item_atts['class'][] = ( $menu_depth == 0 ? 'main-menu-item' : 'sub-menu-item' );
			$item_atts['class'][] = ( $menu_depth >=2 ? 'sub-sub-menu-item' : '' );
			$item_atts['class'][] = ( $menu_depth % 2 ? 'menu-item-odd' : 'menu-item-even' );
			$item_atts['class'][] = 'menu-item-depth-' . $menu_depth;

			/* Addinational Menu Type Classes for Parent Menu Items */
			if( 'mega' == $menu_item->mmm_data['menu_type'] ){
				if( $menu_depth === 0 ) $item_atts['class'][] = 'met_primary_nav_mega';
			}elseif( 'posts' == $menu_item->mmm_data['menu_type'] ){
				if( $menu_depth === 0 ) $item_atts['class'][] = 'met_primary_nav_posts';
			}elseif( 'tabbed_posts' == $menu_item->mmm_data['menu_type'] ){
				if( $menu_depth === 0 ) $item_atts['class'][] = 'met_primary_nav_mega_posts';
			}elseif( 'advanced' == $menu_item->mmm_data['menu_type'] ){
				if( $menu_depth === 0 ) $item_atts['class'][] = 'met_primary_nav_mega_advanced';
			}

			if( 'tabbed_posts' == $this->mmm_item_parent_type ){
				if( $menu_depth === 1 ){
					$tab_cat_id = $menu_item->mmm_data['tab_category'];
					$item_atts['data-cat'] = $tab_cat_id;

					$this->tabbed_post_items[$this->mmm_item_parent_id][] = $menu_item->ID;
					//array_push( $this->tabbed_post_items[$this->mmm_item_parent_id], $menu_item->ID );

					$indent = "\t\t\t";
				}
			}elseif( 'mega' == $this->mmm_item_parent_type ){
				if( isset($menu_item->mmm_data['column_type_link_size']) AND ( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'link' ) AND $menu_depth == 1 ) $item_atts['class'][] = 'mmm-column-'.$menu_item->mmm_data['column_type_link_size'];
				if( isset($menu_item->mmm_data['column_type_widget_size']) AND ( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'widget' ) AND $menu_depth == 1 ) $item_atts['class'][] = 'mmm-column-'.$menu_item->mmm_data['column_type_widget_size'];
				if( isset($menu_item->mmm_data['column_html_content_size']) AND ( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'advanced' ) AND $menu_depth == 1 ) $item_atts['class'][] = 'mmm-column-'.$menu_item->mmm_data['column_html_content_size'];
			}

			//if( $menu_depth === 0 ) $item_atts['class'][] = 'met_vcenter';

			$item_atts_class = empty( $menu_item->classes ) ? array() : (array) $menu_item->classes;
			$item_atts['class'][] = esc_attr( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $item_atts_class ), $menu_item ) ) );

			$item_atts = apply_filters('mmm_nav_atts', $item_atts, true, ' ');

			$the_title = apply_filters('the_title', $menu_item_title, $menu_item->ID);

			$item_output = apply_filters('mmm_parse_html_markup', 'start_el', 'li', array(
				'item_atts' => $item_atts,
				'indent' => $indent
			));

			$link_output = apply_filters('mmm_parse_html_markup', 'start_el', 'a', array(
				'args' => array(
					'before' 		=> $menu_args->before,
					'after' 		=> $menu_args->after,
					'link_before' 	=> $menu_args->link_before,
					'link_after' 	=> $menu_args->link_after
				),
				'link_atts' => $link_atts,
				'the_title' => $the_title,
			));


			// Mega Menu -> Widget
			if( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'widget' AND $menu_depth == 1 ){
				$item_has_widget = true;
				$sidebar_prefix = 'mc-mm-';

				$mega_output = $item_output;

				global $wp_registered_sidebars;
				$widgetcolums = wp_get_sidebars_widgets();

				$mega_output .= "\r\n";
				$mega_output .= "\t\t";
				$mega_output .= '<ul id="mmm-sidebar-'.$menu_item->ID.'" class="sub-menu mmm-sidebar">';
				$mega_output .= "\r\n";

				if ( isset($widgetcolums[$sidebar_prefix.$menu_item->mmm_data['sidebar']]) ){
					ob_start();
					dynamic_sidebar($sidebar_prefix.$menu_item->mmm_data['sidebar']);
					$mega_output .= "\r\n"."\t\t\t".ob_get_contents();
					ob_end_clean();
				}else{
					$mega_output .= '<span class="mmm-sidebar-is-empty">'.sprintf( __( 'Sidebar is empty! Go <a href="%s">Appearance -> Widgets</a> for managining sidebar widgets.', 'met_mega_menu' ), esc_url( admin_url( 'widgets.php' ) ) ).'</span>';
				}

				$mega_output .= "\r\n";
				$mega_output .= '</ul> <!-- #mmm-sidebar-'.$menu_item->ID.' -->';
				$mega_output .= "\r\n";

			}

			// Mega Menu -> Advanced
			if( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'advanced' AND $menu_depth == 1 ){
				$item_has_html = true;

				$html_output = $item_output;

				$html_output .= "\n" . "\t" . '<ul class="sub-menu mmm-advanced">';

				$html_output .= "\n" . "\t". "\t" . '<li class="met_megamenu_advanced_content">';
				$html_output .= ( ( isset($menu_item->mmm_data['column_html_content']) ) ? do_shortcode(stripslashes($menu_item->mmm_data['column_html_content'])) : '' );
				$html_output .= '</a></li><!-- .met_megamenu_advanced_content -->';

				$html_output .= "\n" . "\t".'</ul>'."\n";
			}

			// Mega Menu -> Divider
			if( isset($menu_item->mmm_data['column_type']) AND $menu_item->mmm_data['column_type'] == 'divider' AND $menu_depth == 1 ){
				$item_has_divider = true;

				$divider_output = $item_output;

				$divider_output .= '<!-- divider -->';
			}

			if( 'posts' == $this->mmm_item_parent_type AND $menu_depth >= 1 ){
				// Remove sub level items if exist.
				$final_output = '';
			}elseif( 'mega' == $this->mmm_item_parent_type AND $item_has_widget AND $menu_depth >= 1 ){
				$final_output = $mega_output;
			}elseif( 'mega' == $this->mmm_item_parent_type AND $item_has_html AND $menu_depth >= 1 ){
				$final_output = $html_output;
			}elseif( 'mega' == $this->mmm_item_parent_type AND $item_has_divider AND $menu_depth >= 1 ){
				$final_output = $divider_output;
			}else{
				$final_output = $item_output.apply_filters( 'walker_nav_menu_start_el', $link_output, $menu_item, $menu_depth, $menu_args );
			}

			return $final_output;
		}

		function met_mega_menu_end_el( $el_data = array() ) {
			$link_after = null;
			$item_atts = array();

			$menu_item 		= $el_data['item'];
			$menu_depth		= $el_data['depth'];
			$menu_args		= $el_data['args'];

			$item_atts['class'] = array( 'sub-menu' );

			if( $menu_depth === 0 ){

				// Menu Type -> Posts
				if( 'posts' == $menu_item->mmm_data['menu_type'] ){
					$item_atts['class'][] = 'met_megamenu_posts';
					$item_atts['class'][] = 'mmm_grid';

					// Menu Type -> Posts -> Sub Menu Align
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['posts_submenu_align']) ){
						$posts_submenu_align = $this->mmm_item_data[$this->mmm_item_parent_id]['posts_submenu_align'];
					}else{
						$posts_submenu_align = 'center';
					}

					$item_atts['class'][] = 'mmm-sub-menu-align-'.$posts_submenu_align;

					//$post_cat_data = {category_id}-{taxonomy}
					$post_cat_data 		= ( (strpos($menu_item->mmm_data['posts_category'], '-') > 0) ? explode('-',$menu_item->mmm_data['posts_category']) : array('0',''));
					$post_cat_id 		= $post_cat_data[0];
					$post_cat_taxonomy 	= $post_cat_data[1];

					if( $post_cat_id != 0 ){
						wp_reset_query();

						$args = array(
							'suppress_filters'	=> true,
							'post_type' 		=> 'any',
							'posts_per_page' 	=> $menu_item->mmm_data['posts_limit'],
							'tax_query' 		=> array(
								array(
									'taxonomy' 	=> $post_cat_taxonomy,
									'field' 	=> 'id',
									'terms' 	=> $post_cat_id
								)
							)
						);

						$the_query = new WP_Query( $args );
						if( $the_query->have_posts() ) :

							$link_after .= "\n" . "\t" . '<ul '.apply_filters('mmm_nav_atts', $item_atts, true, ' ').'>';

							while ( $the_query->have_posts() ) :
								$the_query->the_post();

								$id 	= get_the_ID();
								$imgurl = wp_get_attachment_url( get_post_thumbnail_id( $id ) );

								$imgurl = apply_filters('mmm_post_thumbnail_url', $imgurl);

								$th_hover_effect = apply_filters('mmm_post_thumbnail_effect', get_the_ID());

								$post_title		= get_the_title();
								$post_link 		= get_permalink();

								$link_after .= "\n" . "\t". "\t" . '<li class="met_megamenu_post_item mmm-th-effect-'.$th_hover_effect.'">';

								$link_after .= '<img src="'.$imgurl.'" alt="'.$post_title.'" />';

								$link_after .= '<div class="figcaption">';
								$link_after .= '<h2>'.$post_title.'</h2>';
								$link_after .= '<a href="'.$post_link.'" title="'.$post_title.'">...</a>';
								$link_after .= '</div>';

								$link_after .= '</li><!-- .met_megamenu_post_item -->';

							endwhile;

							$link_after .= "\n" . "\t".'</ul>'."\n";
						endif;
						wp_reset_postdata();
					}
				}

				// Menu Type -> Advanced
				elseif( 'advanced' == $menu_item->mmm_data['menu_type'] ){
					$item_atts['class'][] = 'mmm-advanced';
					$item_atts['class'][] = ( (isset($menu_item->mmm_data['html_content_full']) AND $menu_item->mmm_data['html_content_full'] == '1') ? 'mmm-sub-menu-is-full-width' : '' );

					// Menu Type -> Advanced -> Sub Menu Align
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['html_submenu_align']) ){
						$html_submenu_align = $this->mmm_item_data[$this->mmm_item_parent_id]['html_submenu_align'];
					}else{
						$posts_submenu_align = 'center';
					}

					$item_atts['class'][] = 'mmm-sub-menu-align-'.$html_submenu_align;

					$link_after .= "\n" . "\t" . '<ul '.apply_filters('mmm_nav_atts', $item_atts, true, ' ').'>';

					$link_after .= "\n" . "\t". "\t" . '<li class="met_megamenu_advanced_content">';
					$link_after .= ( ( isset($menu_item->mmm_data['html_content']) ) ? do_shortcode(stripslashes($menu_item->mmm_data['html_content'])) : '' );
					$link_after .= '</a></li><!-- .met_megamenu_advanced_content -->';

					$link_after .= "\n" . "\t".'</ul>'."\n";
				}
			}

			$output = apply_filters('mmm_parse_html_markup', 'end_el', 'li', array(
				'menu_ID' 		=> $menu_item->ID,
				'link_after' 	=> $link_after,
			));

			if( $menu_depth >= 1 ){
				if( 'posts' == $this->mmm_item_parent_type ){
					$output = '';
				}
			}

			return $output;
		}

		function met_mega_menu_start_lvl( $lvl_data = array() ){
			$item_atts = array();
			$menu_type = $output = null;

			$depth = $lvl_data['depth'];
			$args = $lvl_data['args'];


			$indent = str_repeat("\t", $depth);
			$display_depth = ( $depth + 1);

			$item_atts['class'] = array(
				'sub-menu',
				( $display_depth % 2  ? 'menu-odd' : 'menu-even' ),
				( $display_depth >=2 ? 'sub-sub-menu' : '' ),
				'menu-depth-' . $display_depth
			);

			// Menu Type -> Mega Menu
			if( $this->mmm_item_data[$this->mmm_item_parent_id]['menu_type'] == 'mega' ){

				if( $display_depth === 1 ){
					// Menu Type -> Mega Menu -> Full Width Sub
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['mega_submenu_full']) AND $this->mmm_item_data[$this->mmm_item_parent_id]['mega_submenu_full'] == '1' ){
						$item_atts['class'][] = 'mmm-sub-menu-is-full-width';
					}

					// Menu Type -> Mega Menu -> Sub Menu Align
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['mega_submenu_align']) ){
						$mega_submenu_align = $this->mmm_item_data[$this->mmm_item_parent_id]['mega_submenu_align'];
					}else{
						$mega_submenu_align = 'center';
					}

					$item_atts['class'][] = 'mmm-sub-menu-align-'.$mega_submenu_align;
				}


				// Menu Type -> Tabbed Posts
			}elseif( $this->mmm_item_data[$this->mmm_item_parent_id]['menu_type'] == 'tabbed_posts' ){
				$item_atts['class'][] = 'met_megamenu_tabbed_posts_wrapper';

				if( $display_depth === 1 ){
					// Menu Type -> Tabbed Posts -> Sub Menu Align
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['tab_posts_submenu_align']) ){
						$tab_posts_submenu_align = $this->mmm_item_data[$this->mmm_item_parent_id]['tab_posts_submenu_align'];
					}else{
						$tab_posts_submenu_align = 'center';
					}

					$item_atts['class'][] = 'mmm-sub-menu-align-'.$tab_posts_submenu_align;
				}
			}else{
				// Menu Type -> Dropdown
				if( $display_depth === 1 ){
					if( isset($this->mmm_item_data[$this->mmm_item_parent_id]['dropdown_submenu_align']) ){
						$dropdown_submenu_align = $this->mmm_item_data[$this->mmm_item_parent_id]['dropdown_submenu_align'];
					}else{
						$dropdown_submenu_align = 'left';
					}
					$item_atts['class'][] = 'mmm-sub-menu-align-'.$dropdown_submenu_align;
				}
			}

			$item_atts = apply_filters('mmm_nav_atts', $item_atts, true, ' ');

			$markup_el_id = 'default';

			if( in_array($this->mmm_item_parent_type, $this->mmm_spec_menu_type_html_markup) ){
				$markup_el_id = $this->mmm_item_parent_type;
			}

			$output = apply_filters('mmm_parse_html_markup', 'start_lvl', $markup_el_id, array(
				'indent' => $indent,
				'item_atts' => $item_atts,
			));

			return $output;
		}

		function met_mega_menu_end_lvl( $lvl_data = array() ){
			$output = $tab_item_data = $tab_category_output = null;
			$tab_item_ids = array();

			$depth = $lvl_data['depth'];
			$args = $lvl_data['args'];

			$indent = str_repeat("\t", $depth);

			if( 'tabbed_posts' == $this->mmm_item_parent_type ){
				$tab_item_ids = (array)array_unique($this->tabbed_post_items[$this->mmm_item_parent_id]);
				if($depth === 0){
					foreach( $tab_item_ids as $tab_item ){
						//parse_str(get_post_meta( $tab_item, $this->mmm_key, true), $tab_item_data);
						$tab_item_data = $this->mmm_item_data[$tab_item];

						//$tab_cat_data = {category_id}-{taxonomy}
						$tab_cat_data 		= ( (strpos($tab_item_data['tab_category'],'-') > 0) ? explode('-',$tab_item_data['tab_category']) : array('0',''));
						$tab_cat_id 		= $tab_cat_data[0];
						$tab_cat_taxonomy 	= $tab_cat_data[1];

						if( $tab_cat_id != 0 ){
							$tab_category_output .= "\n" . "\t". "\t" .'<ul class="met_megamenu_tabbed_posts mmm_grid" data-cat="' . $tab_item_data['tab_category'] . '">';

							wp_reset_query();

							$tab_posts_number = $this->mmm_item_data[$this->mmm_item_parent_id]['tab_posts_limit'];
							$tab_post_args = array(
								'suppress_filters'	=> true,
								'post_type' 		=> 'any',
								'posts_per_page' 	=> $tab_posts_number,
								'tax_query' => array(
									array(
										'taxonomy' 	=> $tab_cat_taxonomy,
										'field' 	=> 'id',
										'terms' 	=> $tab_cat_id
									)
								)
							);

							$tab_post_query = new WP_Query( $tab_post_args );
							$upload_dir = wp_upload_dir();

							while ( $tab_post_query->have_posts() ) :
								$tab_post_query->the_post();

								$imgurl = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

								$imgurl = apply_filters('mmm_tabbed_post_thumbnail_url', $imgurl);

								$th_hover_effect = apply_filters('mmm_tabbed_post_thumbnail_effect', get_the_ID());

								$tab_category_output .= "\n" . "\t". "\t" . "\t" .'<li class="met_megamenu_tabbed_post_item mmm-th-effect-'.$th_hover_effect.'">';

								$tab_category_output .= '<img src="'.$imgurl.'" alt="'.esc_attr( get_the_title() ).'" />';

								$tab_category_output .= '<div class="figcaption">';
								$tab_category_output .= '<h2>'.get_the_title().'</h2>';
								$tab_category_output .= '<a href="'.get_permalink().'" title="'.esc_attr( get_the_title() ).'">...</a>';
								$tab_category_output .= '</div>';
								$tab_category_output .= '</li><!-- .met_megamenu_tabbed_post_item -->';

							endwhile;

							wp_reset_postdata();

							$tab_category_output .= "\n" . "\t". "\t" .'</ul><!-- .met_megamenu_tabbed_posts -->';
						}
					}
				}
			}

			$markup_el_id = 'default';

			if( in_array($this->mmm_item_parent_type, $this->mmm_spec_menu_type_html_markup) ){
				$markup_el_id = $this->mmm_item_parent_type;
			}

			$output = apply_filters('mmm_parse_html_markup', 'end_lvl', $markup_el_id, array(
				'indent' => $indent,
				'tab_category_output' => $tab_category_output
			));

			return $output;
		}
	}
}