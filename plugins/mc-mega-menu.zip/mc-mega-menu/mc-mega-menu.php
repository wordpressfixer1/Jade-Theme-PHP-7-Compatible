<?php
/**
 * Full Functional Mega Menu from MET Creative
 *
 * @package   MET_Mega_Menu_Core
 * @author    Murat KARAÇAM <mail@mrtkrcm.com>
 * @license   You should have purchased a license from http://metcreative.com
 * @link      http://l.metc.in/mc-mega-menu
 * @copyright Copyright 2014 Murat KARAÇAM, MET Creative http://metcreative.com
 *
 * Plugin Name:       (mc) Mega Menu
 * Plugin URI:        http://l.metc.in/mc-mega-menu
 * Description:       Full Functional Mega Menu from MET Creative
 * Version:           1.0.0
 * Author:            MET Creative
 * Author URI:        http://metcreative.com
 * Text Domain:       met_mega_menu
 * License:           You should have purchased a license from http://metcreative.com
 * Domain Path:       /languages/
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'MMM_VERSION', '1.0.0' );
define( 'MMM_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'MMM_DIR_NAME', dirname( plugin_basename( __FILE__ ) ) );
define( 'MMM_ABS', dirname(__FILE__) );
define( 'MMM_DEV_MODE', false );

require_once MMM_ABS.'/class-mmm_walkers.php';
require_once MMM_ABS.'/class-mmm_core.php';

new MET_Mega_Menu_Core();

	/* Plugin Updates */
	require_once MMM_ABS.'/wp-updates-plugin.php';
	new WPUpdatesPluginUpdater_660( 'http://wp-updates.com/api/2/plugin', plugin_basename(__FILE__));

$r = array();

$r['suhosin_post_maxvars'] = ini_get( 'suhosin.post.max_vars' );
$r['suhosin_request_maxvars'] = ini_get( 'suhosin.request.max_vars' );
$r['max_input_vars'] = ini_get( 'max_input_vars' );

//print_r($r);