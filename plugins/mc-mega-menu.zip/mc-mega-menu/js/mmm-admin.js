(function($) {
    var $sub_section_data_obj           = {};

    var met_mega_menu = {

        init: function(){

            met_mega_menu.section_toggler();

            met_mega_menu.sub_section_toggler();

            met_mega_menu.met_mega_sub_section_control();

            met_mega_menu.checkbox_set_value();

            met_mega_menu.met_mega_WP_init();

            $(document).ready(function(){
                met_mega_menu.mfp_init();
                met_mega_menu.wp_editor_init();
                met_mega_menu.met_mega_menu_collect_data();
                met_mega_menu.fa_selector_init();
                met_mega_menu.sidebar_init();
                met_mega_menu.image_uploader();
            });
        },

        met_mega_sub_section_control: function(status){
            setTimeout(function(){

                if(status == 'new' || status == 'sortstop'){
                    $sub_section_data_obj           = {};
                }

                jQuery('.met_mega_menu_sections_box[data-parent_section]').each(function(){
                    var $sub_section               = jQuery(this);

                    $sub_section.attr('data-parent_match','false');
                    $sub_section.attr('data-parent_set','false');

                    var $data_sub_section_id     = $sub_section.data('section_id');
                    var $data_parent_section     = $sub_section.data('parent_section');
                    var $data_parent_option      = $sub_section.data('parent_option');
                    var $data_parent_value       = $sub_section.data('parent_value');

                    if($sub_section_data_obj[$data_sub_section_id] == undefined){
                        $sub_section_data_obj[$data_sub_section_id] = { section: $data_parent_section, option: $data_parent_option,value: $data_parent_value};
                    }
                });

                var $sub_section_data_obj_map = jQuery.map( $sub_section_data_obj, function( parent_data, sub_section_id ) {

                    jQuery('.met_mega_menu_sections_box[data-section_id="'+sub_section_id+'"]').each(function(){

                        var $this_section           = jQuery(this);

                        var $this_menu_item         = $this_section.parents('.menu-item');
                        var $this_menu_parent_id    = jQuery('.menu-item-data-parent-id',$this_menu_item).val();

                        var $this_parent_menu_item  = jQuery('#menu-item-'+$this_menu_parent_id);
                        var $this_parent_section    = jQuery('.met_mega_menu_sections_box[data-section_id="'+parent_data.section+'"]',$this_parent_menu_item);
                        var $this_parent_option     = jQuery('.met_mega_menu_'+parent_data.option,$this_parent_section);
                        var $this_parent_value      = $this_parent_option.filter(':checked').val();

                        var $this_menu_item_title   = $this_menu_item.find('.menu-item-title').html();

                        if( $this_menu_item.hasClass('menu-item-depth-'+$this_section.data('depth')) ){
                            $this_parent_option.on('click',function(){
                                $this_parent_value      = $this_parent_option.filter(':checked').val();

                                if( $this_parent_value == parent_data.value ){
                                    $this_section.attr('data-parent_match','true');
                                }else{
                                    $this_section.attr('data-parent_match','false');
                                }
                            });

                            if($this_parent_value == parent_data.value){
                                $this_section.attr('data-parent_match','true');
                            }
                        }

                    });

                });

            },1);
        },

        section_toggler: function(){
            jQuery( document ).on('click', '.met_mega_menu_sections_box_header a',
                function(e){
                    var $this       = jQuery(this);
                    var $section    = $this.parents('.met_mega_menu_sections_box');
                    var $options    = $section.find('.met_mega_menu_sections_box_container');

                    if( $section.hasClass('met_mega_menu_sections_inactive') ){
                        $options.slideDown(200,function(){
                            $section.removeClass('met_mega_menu_sections_inactive').addClass('met_mega_menu_sections_active');
                            $this.removeClass('fa-arrow-down').addClass('fa-times');
                            $this.hover(function(){
                                $this.removeClass('fa-times').addClass('fa-times-circle');
                            },function(){
                                $this.removeClass('fa-times-circle').addClass('fa-times');
                            })
                        });
                    }

                    if( $section.hasClass('met_mega_menu_sections_active') ){
                        $options.slideUp(200,function(){
                            $section.removeClass('met_mega_menu_sections_active').addClass('met_mega_menu_sections_inactive');
                            $this.removeClass('fa-times fa-times-circle').addClass('fa-arrow-down');
                        });
                    }

                    e.preventDefault();
                }
            );
        },

        sub_section_toggler : function(){
            jQuery( document ).on('click', 'input[type="radio"].has_relation',
                function(){
                    var $this           = jQuery(this);
                    var relationID      = $this.data('relation');
                    var menuItem        = $this.parents('.met_mega_menu_item');
                    var sectionBox      = $this.parents('.met_mega_menu_sections_box');
                    var relationLabel   = $this.parent().find('span').html();

                    met_mega_menu.toggle_sub_section_options($this,relationID,menuItem,sectionBox,relationLabel);
                }
            );

            jQuery('input[type="radio"].has_relation:checked').each(function(){
                jQuery(this).click();
            });

            jQuery( document ).on('change', 'select.has_relation',
                function(){
                    var $this           = jQuery(this);
                    var relationID      = $this.data('relation');
                    var menuItem        = $this.parents('.met_mega_menu_item');
                    var sectionBox      = $this.parents('.met_mega_menu_sections_box');
                    var relationLabel   = $this.find('option:selected').text();

                    var $selected = $this.find('option:selected').val();
                    relationID = relationID+'-'+$selected;

                    met_mega_menu.toggle_sub_section_options($this,relationID,menuItem,sectionBox,relationLabel);
                }
            );

            jQuery('select.has_relation option:selected').each(function(){
                jQuery(this).trigger('change');
            });
        },

        toggle_sub_section_options : function(el,relationID,menuItem,sectionBox,label){
            sectionBox.find('.met_mega_menu_sub_options').slideUp(200);
            sectionBox.find('.met_mega_menu_sub_options_'+relationID).slideDown(200)

            sectionBox.find('.met_mega_menu_sub_options_'+relationID+' .met_mega_menu_sub_options_header span').html(label);
        },

        image_uploader : function(){
            var uploader_id = 0;

            jQuery( document ).on('click', '.met_mega_menu_upload_button', function(e){
                var $this = jQuery(this);
                var uploader_id = $this.attr('rel');

                met_mega_menu.image_uploader_file_frame(uploader_id);
            });

            jQuery( document ).on('change paste keyup','.met_mega_menu_upload_input', function() {
                var $this = jQuery(this);
                var $id = $this.attr('id');
                $id = $id.replace('edit-','');

                var $url = $this.val();
                met_mega_menu.image_uploader_preview($url,$id);
            });
        },

        image_uploader_file_frame : function(uploader_id){
            var file_frame;

            // If the media frame already exists, reopen it.
            if ( file_frame ) {
                file_frame.open();
                return;
            }

            // Create the media frame.
            file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select Icon Image',
                library: {
                    type: 'image'
                },
                button: {
                    text: 'Insert into Menu'
                },
                multiple: false
            });

            // When an image is selected, run a callback.
            file_frame.on('select', function() {
                attachment = file_frame.state().get('selection').first().toJSON();

                jQuery('#edit-'+uploader_id).val(attachment.url);

                met_mega_menu.image_uploader_preview(attachment.url, uploader_id);
            });

            // Finally, open the modal
            file_frame.open();
        },

        image_uploader_preview : function(url,uploader_id){
            var $preview_el = jQuery('.met_mega_menu_upload_preview_'+uploader_id);
            var $placeholder = '<i class="fa fa-times fa-none"></i>';
            var $preloader = '<i class="fa fa-spinner fa-spin"></i>';
            var $preview = '<img src="'+url+'" />';

            $preview_el.html(''); //clear preview
            $preview_el.html($preloader); //set loader

            if(url == ''){
                $preview_el.html($placeholder); //set placeholder
            }else{
                $preview_el.html($preview); //set preview
            }
        },

        wp_editor_init : function(){
            var $wp_tinymce_editor_id       = 'met_wp_editor';
            var $wp_editor_rel_input        = $('.met_wp_rel');

            jQuery( document ).on('click', '.met_mega_menu_wp_editor_button', function(){
                var $wp_editor_button           = jQuery(this);
                var $wp_editor_option_id        = $wp_editor_button.attr('rel');

                $( "body" ).scrollTop( 1 );
                $('#met_mfp_wp_editor_wrapper').show();

                $wp_editor_rel_input.val($wp_editor_option_id);

                var $wp_textarea            = jQuery('.met_mega_menu_wp_textarea_'+$wp_editor_option_id);
                var $wp_textarea_content    = $wp_textarea.val();

                if( typeof tinymce != "undefined" ) {

                    var editor = tinymce.get( $wp_tinymce_editor_id );
                    if( editor && editor instanceof tinymce.Editor ) {
                        editor.setContent( $wp_textarea_content, {format : 'html'} );
                    } else {
                        jQuery('textarea#'+$wp_tinymce_editor_id).val( $wp_textarea_content );
                    }

                }

                return false;
            });

            jQuery( document ).on('click', '.met_mfp_wp_editor_update', function(){
                var $wp_editor_option_id = $wp_editor_rel_input.val();

                console.log($wp_editor_option_id);

                if( typeof tinymce != "undefined" ) {

                    var editor = tinymce.get( $wp_tinymce_editor_id );
                    $('#'+$wp_tinymce_editor_id+'-tmce').trigger('click');
                    var content = editor.getContent();

                    jQuery('.met_mega_menu_wp_textarea_'+$wp_editor_option_id).val( content );

                }

                $wp_editor_rel_input.val('0');
                $('#met_mfp_wp_editor_wrapper').hide();
            });

            jQuery( document ).on('click', '.met_mfp_wp_editor_cancel', function(){
                $wp_editor_rel_input.val('0');
                $('#met_mfp_wp_editor_wrapper').hide();
            });
        },

        fa_selector_init : function(){

            jQuery( document ).on('click','.met_mega_menu_fa_button',function(){
                var $this = jQuery(this);
                var $id 	= $this.attr('rel');

                jQuery('.met_fa_rel').val($id);
            });

            jQuery( document ).on('click','#met_mfp_fa_icon_list .mmm-button',function(){
                var $this = jQuery(this);
                var $id 	= jQuery('.met_fa_rel').val();
                var $icon 	= $this.data('icon');

                jQuery('#edit-'+$id).val($icon);
                jQuery('.met_mega_menu_fa_preview_'+$id+' i').removeClass();
                jQuery('.met_mega_menu_fa_preview_'+$id+' i').addClass('fa').addClass($icon);

                jQuery('.met_fa_rel').val('');
                $.magnificPopup.close();
            });

            jQuery( document ).on('click', '.met_mfp_fa_cancel',
                function(){
                    jQuery('.met_fa_rel').val('');
                    $.magnificPopup.close();
                }
            );

        },

        checkbox_set_value : function(){
            jQuery( document ).on('click', 'input[type="checkbox"].met_mega_menu_checkbox', function(){
                var $this = jQuery(this);

                if( $this.is(':checked') ){
                    $this.val('1');
                } else{
                    $this.val('');
                }
            });
        },

        mfp_init : function(){
            jQuery('.mmm_mfp').magnificPopup({
                modal: true,
                type: 'inline',
                preloader: false,
                midClick: true,
            });
        },

        sidebar_init: function(){

            //remove old ajax msg on new sidebar select
            jQuery( document ).on('change','.met_mega_menu_select_sidebar',function(){
                var $select_id = jQuery(this).data('relation');
                var $response_el = jQuery('.sidebar-alert-'+$select_id);

                $response_el.fadeOut('slow');
            });

            //add sidebar
            jQuery( document).on('click','.met_mega_menu_add_sidebar_button', function(){
                var $this_button = jQuery(this);
                var $select_id = $this_button.attr('rel');
                var $select_el = jQuery('.met_mega_menu_select_'+$select_id);

                var $response_el = jQuery('.sidebar-alert-'+$select_id);

                var mmm_new_sidebar_name = prompt("Please enter sidebar name", "New MM Sidebar");
                if ( mmm_new_sidebar_name != null ) {
                    jQuery.post(mmm_ajax.ajaxurl, {
                        action : 'mmm-ajax',
                        mmmAjaxNonce : mmm_ajax.mmmAjaxNonce,

                        sidebar_name : mmm_new_sidebar_name,
                        do_action : 'add'
                    }, function( response ) {

                        if( response.status == 'ok' ){
                            jQuery.each( response.new, function( key, value ) {

                                $select_el.find('option').removeAttr('selected');

                                //add and select new option.
                                $select_el.append(jQuery('<option>', {
                                    value: key,
                                    text: value
                                }).attr('selected','selected'));

                                //also add all sidebar selectors.
                                jQuery('.met_mega_menu_select_sidebar').not($select_el).append(jQuery('<option>', {
                                    value: key,
                                    text: value
                                }));

                                //print msg
                                $response_el.html('New Sidebar Added!').fadeIn('slow');
                                setTimeout(function(){
                                    $response_el.fadeOut('slow');
                                }, 2000);

                            });
                        }

                    });
                }
            });

            //remove sidebar
            jQuery( document).on('click','.met_mega_menu_delete_sidebar_button', function(){

                var $this_button = jQuery(this);
                var $select_id = $this_button.attr('rel');
                var $select_el = jQuery('.met_mega_menu_select_'+$select_id);
                var $selected_option = $select_el.find('option:selected');

                var $sidebarID = $selected_option.val();
                var $sidebarName = $selected_option.text();

                var $response_el = jQuery('.sidebar-alert-'+$select_id);

                if($sidebarID == 0){

                    $response_el.html('You need to select sidebar.').fadeIn('slow');
                    setTimeout(function(){
                        $response_el.fadeOut('slow');
                    }, 2000);

                    return false;
                }else{
                    var r = confirm("Are you sure? Selected Sidebar("+$sidebarName+") and All Widget data will be remove PERMANENTLY!");
                    if (r == true) {

                        jQuery.post(mmm_ajax.ajaxurl, {
                            action : 'mmm-ajax',
                            mmmAjaxNonce : mmm_ajax.mmmAjaxNonce,

                            sidebarID : $sidebarID,
                            do_action : 'remove'
                        }, function( response ) {

                            if( response.status == 'ok' ){
                                //remove selected option
                                $selected_option.remove();

                                $select_el.find('option').removeAttr('selected');
                                $select_el.find('option:first').attr('selected','selected');

                                /*
                                 * DEEPTH CHECK - START
                                 * -find entire matched options from other sidebar selects
                                 * */
                                var $other_sidebar_selects = jQuery('.met_mega_menu_select_sidebar').not($select_el);

                                if( $other_sidebar_selects.length ){
                                    $other_sidebar_selects.each(function(){
                                        var $other_sidebar_select_item = jQuery(this); //<select class="met_mega_menu_select_sidebar">
                                        var $other_sidebar_select_option_item = $other_sidebar_select_item.find('option[value="'+$sidebarID+'"]'); //<option value="$sidebarID">

                                        //another menu using this sidebar, remove selected attr and select first sidebar.
                                        if( $other_sidebar_select_option_item.is(':selected') ){
                                            $other_sidebar_select_item.find('option').removeAttr('selected');
                                            $other_sidebar_select_item.find('option:first').attr('selected','selected');

                                            jQuery('.sidebar-alert-'+$other_sidebar_select_item.data('relation')).html('Selected sidebar removed from another menu item.').addClass('sidebar-alert-another-trigger').fadeIn('slow');
                                        }

                                        //remove from another menu items.
                                        $other_sidebar_select_option_item.remove();
                                    });
                                }
                                /*
                                 * DEEPTH CHECK - ENDS
                                 * */

                                $response_el.html('Sidebar Removed!').fadeIn('slow');

                                setTimeout(function(){
                                    $response_el.fadeOut('slow');
                                }, 2000);
                            }
                        });

                    }
                }
            });
        },

        met_mega_menu_collect_data: function(){

            jQuery("#update-nav-menu").submit(function(e) {
                var self = this;
                e.preventDefault();

                $('#menu-to-edit li.menu-item').each(function(){
                    var $menu_item      = $(this);
                    var $menu_item_id   = $('.menu-item-data-db-id',$menu_item).val();

                    var $mmm_data_input = $('.met_mega_menu_item_data',$menu_item);
                    var $mmm_sections   = $('.met_mega_menu_sections_wrapper',$menu_item);
                    var $mmm_options    = $('input, select, textarea',$mmm_sections);

                    $mmm_data_input.val('');

                    $mmm_options.each(function(){
                        if(!$(this).attr('name')){
                            $(this).attr('name',$(this).attr('data-name'));
                        }

                        $(this).attr('data-name', $(this).attr('name'));
                        $(this).attr('name', $(this).attr('name').substring(0, $(this).attr('name').indexOf('[')) );
                    });

                    var $mmm_options_data    = $mmm_options.serialize();

                    $mmm_data_input.val($mmm_options_data);
                    $mmm_options.removeAttr('name');
                });

                self.submit();
                return false;
            });

        },

        met_mega_WP_addItemToMenu : function(menuItem, processMethod, callback) {
            var menu = $('#menu').val(),
                nonce = $('#menu-settings-column-nonce').val();

            processMethod = processMethod || function(){};
            callback = callback || function(){};

            params = {
                'action': 'mmm-add-menu-item',
                'menu': menu,
                'menu-settings-column-nonce': nonce,
                'menu-item': menuItem
            };

            $.post( ajaxurl, params, function(menuMarkup) {
                var ins = $('#menu-instructions');
                processMethod(menuMarkup, params);
                // Make it stand out a bit more visually, by adding a fadeIn
                $( 'li.pending' ).hide().fadeIn('slow');
                $( '.drag-instructions' ).show();
                if( ! ins.hasClass( 'menu-instructions-inactive' ) && ins.siblings().length )
                    ins.addClass( 'menu-instructions-inactive' );
                callback();

                met_mega_menu.met_mega_WP_addItemToMenu_callback();
            });
        },

        met_mega_WP_addItemToMenu_callback : function() {
            met_mega_menu.met_mega_sub_section_control('new');
            met_mega_menu.mfp_init();
        },

        met_mega_WP_init: function(){
            if(typeof wpNavMenu != 'undefined'){
                wpNavMenu.addItemToMenu = met_mega_menu.met_mega_WP_addItemToMenu;

                jQuery(wpNavMenu).ready(function(){
                    wpNavMenu.menuList.on("sortstop", function( event, ui ) {
                        met_mega_menu.met_mega_sub_section_control('sortstop');
                    } );
                });
            }
        }

    };

    met_mega_menu.init();

})(jQuery);