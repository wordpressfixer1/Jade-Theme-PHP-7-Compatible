<?php
class MC_Shortcode_Builder {

	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     1.0.0
	 */
	function __construct(){

		// Load plugin text domain
		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

		add_action( 'init', array($this, 'init') );
		add_action('wp_ajax_mcsb-ajax', array($this, 'mcsb_admin_ajax'));

		if( isset($_GET['dslc']) ){

			add_action( 'media_buttons', array( $this, 'mcsb_media_button' ), 20 );
			add_action( 'wp_footer', array( $this, 'mcsb_popup_html' ) );

			add_filter( 'mc_sb_html_atts', array( $this, 'mcsb_html_atts' ), 10, 3 );

			// Load public-facing style sheet and JavaScript.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}
	}

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		$domain = 'mcsb';
		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );

		load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
		load_plugin_textdomain( $domain, FALSE, basename( plugin_dir_path( dirname( __FILE__ ) ) ) . '/languages/' );
	}

	/**
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles(){
		wp_enqueue_style( 'met-ui', MCSB_DIR_URL . 'ui/css/uikit.min.css', array(), MCSB_VERSION );
		wp_enqueue_style( 'met-ui-addons', MCSB_DIR_URL . 'ui/css/uikit.addons.min.css', array('met-ui'), MCSB_VERSION );
		wp_enqueue_style( 'wp-color-picker' );

		wp_enqueue_style( 'mcsb-style', MCSB_DIR_URL . 'ui/css/mcsb-style.css', array('met-ui'), MCSB_VERSION );

		do_action( 'mcsb/enqueue_styles' );
	}

	/**
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts(){
		wp_register_script( 'met-ui', MCSB_DIR_URL . 'ui/js/uikit.min.js', array('jquery'), MCSB_VERSION, true );
		wp_enqueue_script( 'met-ui-addon-nestable', MCSB_DIR_URL . 'ui/js/addons/nestable.min.js', array('met-ui'), MCSB_VERSION, true );

		/* Iris */
		wp_enqueue_script(
			'iris',
			admin_url( 'js/iris.min.js' ),
			array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ),
			false,
			1
		);
		wp_enqueue_script(
			'wp-color-picker',
			admin_url( 'js/color-picker.min.js' ),
			array( 'iris' ),
			false,
			1
		);
		$colorpicker_l10n = array(
			'clear' => __( 'Clear' ),
			'defaultString' => __( 'Default' ),
			'pick' => __( 'Select Color' )
		);
		wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', $colorpicker_l10n );

		wp_enqueue_script( 'mcsb-script', MCSB_DIR_URL . 'ui/js/mcsb-script.js', array('met-ui'), MCSB_VERSION, true );

		wp_localize_script( 'mcsb-script', 'mcsb_ajax', array(
				'ajaxurl'				=> admin_url( 'admin-ajax.php' ),
				'mcsbAjaxNonce' 		=> wp_create_nonce( 'mcsb-ajax-nonce' ),
			)
		);

		do_action( 'mcsb/enqueue_scripts' );
	}

	/**
	 *
	 * @since    1.0.0
	 */
	function mcsb_admin_ajax(){
		$nonce = $_POST['mcsbAjaxNonce'];

		if ( ! wp_verify_nonce( $nonce, 'mcsb-ajax-nonce' ) )
			die ( 'Nope!');

		$json_response = json_encode( array('html' => do_shortcode(stripslashes($_POST['shortcode_output'])), 'shortcode' => stripslashes($_POST['shortcode_output']) ) );

		header( "Content-Type: application/json" );
		echo $json_response;

		exit();
	}

	/**
	 *
	 * @since    1.0.0
	 */
	function init(){
		do_action( 'mcsb/init' );
	}

	/**
	 *
	 * @since    1.0.0
	 */
	function admin_init(){}

	/**
	 * Wordpress editor, shortcode builder modal trigger button.
	 *
	 * @since    1.0.0
	 */
	public function mcsb_media_button( $editor_id = 'dslcawpeditor' ) {
		$output = '';
		$output = '<a href="#mcsb_modal" data-uk-modal class="button" title="' . __( '(mc) Shortcode Builder', 'mcsb' ) . '"><div class="dashicons dashicons-admin-settings" style="margin:1px 6px 0 0;font-size: 23px;"></div><strong>(mc)</strong> ' . __( 'Shortcode Builder', 'mcsb' ) . '</a>';
		echo $output;

		do_action( 'mcsb/media_button' );
	}

	/**
	 * Filters -> HTML Elements Atts
	 *
	 * @since    1.0.0
	 */
	public function mcsb_html_atts($atts = array(), $doImplode = false, $implodeGlue = ''){
		if(count($atts)){
			foreach ( $atts as $attr => $value ) {
				if(is_array($value)) $value = implode(' ',$value);

				if ( ! empty( $value ) ) {
					$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
					$item_atts_result[] = $attr . '="' . $value . '"';
				}
			}
			return ($doImplode) ? implode($implodeGlue,$item_atts_result) : $item_atts_result;
		}else{
			return;
		}
	}


	/**
	 * Build -> Option
	 *
	 * @since    1.0.0
	 */
	public function mcsb_build_option($key, $param) {

		$field_atts = array();

		$field_atts['name'] = $key;
		$field_atts['id'] = $key;
		$field_atts['class'] = 'mcsb-shortcode-field uk-width-1-1';

		if( isset($param['primary']) AND $param['primary'] === true ){
			$field_atts['data-primary'] = '1';
		}

		$field_atts['data-default'] = isset($param['std']) ? $param['std'] : '';

		$field_label_markup = '<label class="uk-form-label" for="' . $key .'">' . $param['label'] . '</label>';
		$field_desc_markup = ( (!empty($param['desc']) ) ? '<p class="uk-form-help-block uk-text-small uk-text-muted">' . $param['desc'] . '</p>' : '');

		$field_before_markup = '<div class="uk-form-controls">';
		$field_after_markup = '</div>';

		/* BUILD HTML OUTPUT */
		$html = '<div class="uk-form-row">';

		switch( $param['type'] ){
			case 'text'		:
			case 'url' 		:
			case 'email' 	:
			case 'number' 	:

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '<input type="'.$param['type'].'" value="' . $param['std'] . '" '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').' />';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;

				$html .= $output;

				break;

			case 'textarea' :

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '<textarea rows="10" cols="30" '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').'>' . $param['std'] . '</textarea>';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;
				$html .= $output;

				break;

			case 'select' :

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '<select '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').'>';

				foreach( $param['options'] as $value => $option ){
					$output .= '<option value="' . $value . '" ' . ( isset($param['std']) AND $param['std'] == $value ? 'selected' : '' ) . '>' . $option . '</option>';
				}

				$output .= '</select>';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;

				$html .= $output;

				break;

			case 'checkbox' :

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '<input type="checkbox" value="' . $param['std'] . '" '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').' ' . ( $param['std'] ? 'checked' : '' ) . '>';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;

				$html .= $output;

				break;

			case 'color' :

				$field_atts['class'] = $field_atts['class'].' mscb_color_picker';

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '<input type="text" value="' . $param['std'] . '" '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').' />';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;

				$html .= $output;

				break;

			case 'icon' :

				$field_atts['class'] = str_replace('1-1','4-10',$field_atts['class']);
				$field_atts['class'] = $field_atts['class'].' mcsb_fa_input';

				$output = $field_label_markup;
				$output .= $field_before_markup;

				$output .= '
				<button disabled class="uk-button uk-button-primary uk-width-2-10 mcsb_fa_preview"><i '.(( isset($param['std']) AND !empty($param['std']) ) ? 'class="'.str_replace('fa-','uk-icon-',$param['std']).'"' : '').'></i></button>
				<input type="text" value="' . $param['std'] . '" '.apply_filters('mc_sb_html_atts', $field_atts, true, ' ').' />
				<button class="uk-button uk-width-3-10 mcsb_fa_button">'.__('Select','mcsb').'</button>';

				$output .= $field_desc_markup;
				$output .= $field_after_markup;

				$html .= $output;

				break;

			default :
				break;
		}

		$html .= '</div><!-- .uk-form-row -->';

		return "\r\n\t".$html."\r\n";
	}

	/**
	 * Build -> Popup
	 *
	 * @since    1.0.0
	 */
	public function mcsb_popup_html() {
		do_action( 'mcsb/mcsb_popup_html/before' );

		/**
		 * Popup -> Font Awesome icon selector
		 *
		 * @since 1.0.0
		 */
		$pattern = '/\.(fa-(?:\w+(?:-)?)+):before{content:/';
		$subject = file_get_contents(MCSB_DIR_URL. 'ui/css/fontawesome.css');

		preg_match_all($pattern, $subject, $matches, PREG_SET_ORDER);

		$fontAwesome = array();

		foreach($matches as $match){
			$fontAwesome[] = $match[1];
		}
		?>
		<div id="mcsb_fa_modal" class="uk-modal">
			<div class="uk-modal-dialog uk-modal-dialog-frameless">
				<a class="uk-modal-close uk-close uk-close-alt"></a>

				<div class="uk-panel uk-panel-box uk-panel-box-primary uk-width-1-1 ">
					<h3 class="uk-panel-title"><?php _e('Select Icon','mcsb') ?></h3>
					<?php
						echo '<p id="mcsb_fa_modal_icon_list" data-uk-margin>';
						foreach ( $fontAwesome as $icon ){
							echo '<button class="uk-button uk-width-1-10" data-icon="'.str_replace('fa-','',$icon).'"><i class="'.str_replace('fa-','uk-icon-',$icon).'"></i></button> ';
						}
						echo '</p>';
					?>
				</div>

				<input type="hidden" id="met_fa_rel" value="" />
			</div>
		</div>

		<?php
		/**
		 * Popup -> MC Shortcode Builder
		 *
		 * @since 1.0.0
		 */

		$mcsb_shortcodes_db = apply_filters('mcsb/data/shortcode','');
		?>
		<div id="mcsb_modal" class="uk-modal">
			<div class="uk-modal-dialog uk-modal-dialog-frameless">
				<a class="uk-modal-close uk-close uk-close-alt"></a>

				<div class="uk-grid uk-grid-preserve">
					<div class="uk-panel uk-panel-box uk-panel-box-primary uk-width-1-1">
						<h3 class="uk-panel-title"><i class="uk-icon-sliders uk-text-muted"></i> <abbr class="uk-text-bold" title="MetCreative">(mc)</abbr> Shortcode Builder</h3>

						<?php if( is_array($mcsb_shortcodes_db) AND count($mcsb_shortcodes_db) > 0 ): ?>
						<?php ksort($mcsb_shortcodes_db) ?>
						<div class="uk-panel uk-panel-box uk-width-1-1">
							<h3 class="uk-panel-title"><?php _e('Select Shortcode', 'mcsb'); ?></h3>

							<ul id="mcsb-shortcode-nav" class="uk-nav uk-nav-side">
								<?php
									foreach( $mcsb_shortcodes_db as $shortcode_id => $shortcode ) {
										echo '<li><a href="#" data-id="' . $shortcode_id . '"><i class="uk-icon-' . $shortcode['icon'] . '"></i> ' . $shortcode['title'] . '</a></li><li class="uk-nav-divider"></li>';
									}
								?>
							</ul>

							<div class="uk-form">
								<select id="mcsb-shortcode-selector" class="uk-width-1-1 uk-hidden">
									<?php
										foreach( $mcsb_shortcodes_db as $shortcode_id => $shortcode ) {
											echo '<option value="' . $shortcode_id . '" data-icon="' . $shortcode['icon'] . '">' . $shortcode['title'] . '</option>';
										}
									?>
								</select>
							</div>
						</div>

						<div id="mcsb-shortcode-options-wrapper" class="uk-width-1-1 uk-hidden">
							<hr class="uk-grid-divider uk-grid-preserve">

							<div class="uk-form uk-form-horizontal uk-panel uk-panel-box uk-width-1-1">
								<div id="mcsb-selected-shortcode-title" class="uk-panel-badge uk-badge"></div>
								<h3 class="uk-panel-title"><?php _e('Shortcode Options','mcsb') ?></h3>

								<?php
									$html = '';
									$mc_sb_shortcode_holder_atts = array();

									$child_item_markup = '
									<li id="{{$child_id_att}}" class="uk-nestable-list-item {{$visibility_class}}">
										<div class="uk-nestable-item">
											<div class="uk-nestable-handle"></div>
											<div class="uk-badge mcsb-child-shortcode-order">{{$child_order}}</div>
											<span class="mcsb-child-shortcode-title">...</span>

											<div class="uk-button-group uk-float-right">
												<button class="uk-button uk-button-mini uk-button-danger" data-uk-toggle="{target:\'.mcsb-child-shortcode-remove_confirm_{{$shortcode_id}}_{{$child_order}}\'}"><i class="uk-icon-times"></i> </button>
												<button class="uk-button uk-button-mini mcsb-child-shortcode-option-toggler" data-uk-toggle="{target:\'.mcsb-child-shortcode-options_{{$shortcode_id}}_{{$child_order}}\'}"><i class="uk-icon-{{$child_toggle_icon}}"></i></button>
											</div>

											<div class="uk-hidden uk-float-right uk-button-group uk-margin-small-right mcsb-child-shortcode-remove_confirm_{{$shortcode_id}}_{{$child_order}}">
												<button class="mcsb-remove-child uk-button uk-button-mini uk-button-danger"><i class="uk-icon-check"></i> ' . __('Yes', 'mcsb') . '</button>
												<button class="uk-button uk-button-mini" disabled>' . __('Sure', 'mcsb') . ' <i class="uk-icon-question"></i></button>
											</div>

											<div id="mcsb-child-shortcode-options_{{$shortcode_id}}_{{$child_order}}" class="uk-margin-small-top uk-panel uk-panel-box {{$visibility_class}} mcsb-child-shortcode-options_{{$shortcode_id}}_{{$child_order}}">
												{{$child_fields}}
											</div>
										</div>
									</li>';

									foreach( $mcsb_shortcodes_db as $shortcode_id => $shortcode ) {
										$shortcode_has_child = false;

										$mc_sb_shortcode_holder_atts['data-shortcode-template'] = $shortcode['template'];

										if( array_key_exists('child', $shortcode ) AND count($shortcode['child']['options']) > 0 ) {
											$mc_sb_shortcode_holder_atts['data-shortcode-child-template'] = $shortcode['child']['template'];
											$mc_sb_shortcode_holder_atts['data-shortcode-has-child'] = '1';
											$shortcode_has_child = true;
										}

										$mc_sb_shortcode_holder_atts['id'] = 'mcsb-shortcode-options_'.$shortcode_id;
										$mc_sb_shortcode_holder_atts['data-shortcode-id'] = $shortcode_id;

										$mc_sb_shortcode_holder_atts['class'] = 'mcsb-shortcode-options';

										$html .= "\r\n";
										$html .= '<!-- START | #mcsb-shortcode-options_'.$shortcode_id.' -->';
										$html .= "\r\n";
										$html .= '<div '.apply_filters('mc_sb_html_atts', $mc_sb_shortcode_holder_atts, true, ' ').'>';

										foreach( $shortcode['options'] as $key => $param ) {
											$html .= $this->mcsb_build_option($key, $param);
										}

										if( array_key_exists('desc', $shortcode) AND !empty($shortcode['desc']) ) {
											$html .= '<div class="uk-form-row"><div class="uk-alert uk-text-small uk-margin-bottom-remove">' . $shortcode['desc'] . '</div></div>';
										}

										if( $shortcode_has_child ) {
											$child_item_fields = '';
											foreach( $shortcode['child']['options'] as $child_key => $child_param ) {
												$child_item_fields .= $this->mcsb_build_option($child_key, $child_param);
											}

											$html .= '<ul class="uk-nestable mcsb-child-shortcode-options uk-margin-top" data-uk-nestable="{maxDepth:1}">';

											#------- FIRST CHILD --------#
											$child_item_args = array('{{$child_order}}','{{$shortcode_id}}','{{$child_fields}}','{{$child_id_att}}','{{$visibility_class}}','{{$child_toggle_icon}}');
											$child_item_params = array('1', $shortcode_id, $child_item_fields, 'first-child-'.$shortcode_id, '', 'minus');

											$html .= str_replace($child_item_args,$child_item_params,$child_item_markup);
											#------- FIRST CHILD --------#

											#------- INVISIBLE CLONE --------#
											$child_item_args = array('{{$child_order}}','{{$shortcode_id}}','{{$child_fields}}','{{$child_id_att}}','{{$visibility_class}}','{{$child_toggle_icon}}');
											$child_item_params = array('-inc-', $shortcode_id, $child_item_fields, 'clone-'.$shortcode_id, 'uk-hidden', 'plus');

											$html .= str_replace($child_item_args,$child_item_params,$child_item_markup);
											#------- INVISIBLE CLONE --------#

											$html .= '</ul>';

											$html .= '<div class="uk-form-row"><button type="button" class="uk-button uk-button-small add-child" data-shortcode-id="' . $shortcode_id . '"><i class="uk-icon-plus"></i> ' . $shortcode['child']['title'] . '</button></div>';
										}

										$html .= "\r\n";
										$html .= '</div>';
										$html .= "\r\n";
										$html .= '<!-- END | #mc-sb-shortcode-holder_'.$shortcode_id.' -->';
										$html .= "\r\n";
									}

									echo $html;
								?>
							</div>

							<div id="mcsb_shortcode_preview_holder" class="uk-hidden">
								<hr class="uk-grid-divider uk-grid-preserve">

								<div class="uk-panel uk-panel-box uk-width-medium-1-1">
									<div class="uk-panel-badge uk-badge uk-badge-success"><i class="uk-icon-magic"></i> <?php _e('Live Preview', 'mcsb'); ?></div>
									<div id="mcsb_shortcode_preview"><i class="uk-icon-spinner uk-icon-spin"></i></div>
									<hr>
									<div class="uk-badge uk-badge-success uk-float-right"><i class="uk-icon-code"></i> <?php _e('Live Code', 'mcsb'); ?></div>
									<br>
									<pre id="mcsb_shortcode_preview_code" class="uk-text-muted uk-text-small uk-width-1-1"><code></code></pre>
								</div>
							</div>

							<hr class="uk-grid-divider uk-grid-preserve">

							<input type="hidden" id="mcsb-active-shortcode-id" value="0">
							<div class="uk-panel uk-align-center uk-panel-box uk-width-1-1">
								<div class="uk-button-group uk-align-center">
									<input type="button" id="mcsb-insert-shortcode" class="uk-button uk-button-success uk-width-2-4" value="<?php _e('Insert Shortcode', 'mcsb'); ?>" />
									<input type="button" id="mcsb-show-shortcode-preview" class="uk-button uk-button-primary uk-width-1-4" value="<?php _e('Live Preview', 'mcsb'); ?>" />
									<input type="button" id="mcsb-cancel-shortcode" class="uk-button uk-button-danger uk-width-1-4" value="<?php _e('Cancel', 'mcsb'); ?>" />
								</div>
							</div>

						</div>

						<?php else: ?>
						<?php _e('Shortcodes not found!','mcsb'); ?>
						<?php endif; ?>
					</div>

				</div>
			</div>
		</div>
	<?php

		do_action( 'mcsb/mcsb_popup_html/after' );
	}
}