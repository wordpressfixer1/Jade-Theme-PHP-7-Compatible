<?php get_header(); the_post(); ?>
	
	<?php the_content(); ?>

<?php get_footer(); ?>