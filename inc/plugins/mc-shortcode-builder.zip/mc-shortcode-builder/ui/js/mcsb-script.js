(function($) {

    var $shortcode_options = $('.mcsb-shortcode-options'),
        $shortcode_options_label = $('#mcsb-selected-shortcode-title'),
        $shortcode_selector = $('#mcsb-shortcode-selector'),
        $first_shortcode_nav = $('#mcsb-shortcode-nav');

    var mc_shortcode_builder = {

        /*=====================================
        =     Initalize shortcode builder     =
        =====================================*/
        init: function(){

            $(document).ready(function(){
                mc_shortcode_builder.switch_shortcode_options();
                mc_shortcode_builder.init_wp_color_picker();
                mc_shortcode_builder.init_ui_modal();
                mc_shortcode_builder.update_child_panel_title();
                mc_shortcode_builder.toggle_child();

                $('.add-child').on('click', function() {
                    mc_shortcode_builder.add_child($(this).attr('data-shortcode-id'));
                });

                $('.mcsb-remove-child').live('click', function(){
                    mc_shortcode_builder.remove_child($(this));
                });

                $('.uk-nestable').on('nestable-change', function(){
                    mc_shortcode_builder.update_child_panel_order($(this));
                });

                $('#mcsb-insert-shortcode').on('click', function(){
                    mc_shortcode_builder.build_shortcode('insert');
                });

                $('#mcsb-show-shortcode-preview').on('click', function(){
                    mc_shortcode_builder.build_shortcode('preview');
                });
            });

        },

        /*=================================================================
        =            Build shortcode and send output to editor            =
        =================================================================*/
        build_shortcode: function(action){

            var active_shortcode_id = $('#mcsb-active-shortcode-id').val();
            var $active_shortcode_options = $(".mcsb-shortcode-options[data-shortcode-id='"+active_shortcode_id+"']");
            var active_shortcode_has_child = false;
            var active_shortcode_template = $active_shortcode_options.attr('data-shortcode-template');
            var active_shortcode_child_template = null;
            var active_shortcode_atts = null;
            var active_shortcode_atts_render = null;
            var active_shortcode_content = null;
            var active_child_shortcode_atts = null;
            var active_child_shortcode_atts_render = '';
            var active_child_shortcode_content = null;

            var active_shortcode_editor_result = '';

            var attr = $active_shortcode_options.attr('data-shortcode-has-child');
            if (typeof attr !== typeof undefined && attr !== false) {
                active_shortcode_has_child = true;
            }

            var $active_shortcode_fields = $(".mcsb-shortcode-options[data-shortcode-id='"+active_shortcode_id+"'] > .uk-form-row .mcsb-shortcode-field");
            var $active_shortcode_child_options = null;

            if( active_shortcode_has_child == true ){
                $active_shortcode_child_options = $active_shortcode_options.find('.mcsb-child-shortcode-options').find('.uk-nestable-list-item').not('.uk-hidden');
                active_shortcode_child_template = $active_shortcode_options.attr('data-shortcode-child-template');

                $active_shortcode_child_options.each(function(){

                    active_child_shortcode_atts = jQuery.map($(this).find('.mcsb-shortcode-field'), function(el, index) {
                        var $el = jQuery(el);

                        if( $el.attr('id') === 'content' ) {
                            active_child_shortcode_content = $el.val();
                            return '';
                        } else if( $el.attr('id') === 'last' ) {
                            if( $el.is(':checked') ) {
                                return $el.attr('id') + '="true"';
                            } else {
                                return '';
                            }
                        } else {
                            if($el.val() != ''){
                                return $el.attr('id') + '="' + $el.val() + '"';
                            }else{
                                return '';
                            }
                        }
                    });

                    active_child_shortcode_atts = active_child_shortcode_atts.join(' ').trim();
                    active_child_shortcode_atts_render += active_shortcode_child_template.replace('{{attributes}}', active_child_shortcode_atts).replace('{{content}}', active_child_shortcode_content);
                });
            }

            active_shortcode_atts = jQuery.map($active_shortcode_fields, function(el, index) {
                var $el = jQuery(el);

                if( $el.attr('id') === 'content' ) {
                    active_shortcode_content = $el.val();
                    return '';
                } else if( $el.attr('id') === 'last' ) {
                    if( $el.is(':checked') ) {
                        return $el.attr('id') + '="true"';
                    } else {
                        return '';
                    }
                } else {
                    if($el.val() != ''){
                        return $el.attr('id') + '="' + $el.val() + '"';
                    }else{
                        return '';
                    }
                }
            });

            active_shortcode_atts = active_shortcode_atts.join(' ').trim();
            active_shortcode_atts_render = active_shortcode_template.replace('{{attributes}}', active_shortcode_atts).replace('{{content}}', active_shortcode_content);

            if( active_shortcode_has_child == true ){
                active_shortcode_editor_result = active_shortcode_atts_render.replace('{{child_shortcode}}', active_child_shortcode_atts_render);
            }else{
                active_shortcode_editor_result = active_shortcode_atts_render;
            }

            if( action == 'insert' ){
                window.send_to_editor( active_shortcode_editor_result );

                mc_shortcode_builder.after_shortcode_insert();
            }else if( action == 'preview' ){
                $('#mcsb_shortcode_preview_holder').removeClass('uk-hidden');

                $('#mcsb_shortcode_preview').html('<i class="uk-icon-spinner uk-icon-spin"></i>');
                $('#mcsb_shortcode_preview_code').hide();

                jQuery.post(mcsb_ajax.ajaxurl, {
                    action : 'mcsb-ajax',
                    mcsbAjaxNonce : mcsb_ajax.mcsbAjaxNonce,
                    shortcode_output : active_shortcode_editor_result,
                }, function( response ) {

                    $('#mcsb_shortcode_preview').html(response.html).fadeIn('slow').addClass('uk-animation-shake');
                    $('#mcsb_shortcode_preview_code').fadeIn('slow').find('code').html(response.shortcode);

                    setTimeout(function(){
                        $('#mcsb_shortcode_preview').removeClass('uk-animation-shake');
                    }, 500);
                });
            }
        },

        /*========================================================
        =            Hook for after shortcode insert.            =
        ========================================================*/
        after_shortcode_insert: function(){
            //Remove cloned child shortcodes.
            $('.uk-nestable-list-item-CLONE').remove();

            //Reset all fields to default.
            $('.mcsb-shortcode-field').each(function(){
                var $field = jQuery(this);
                var default_val = $field.attr('data-default');

                if( $field.prop("tagName") == 'INPUT' || $field.prop("tagName") == 'TEXTAREA' ){
                    $field.val(default_val);
                }

                if( $field.prop("tagName") == 'SELECT' ){
                    $field.find('option').removeAttr('selected');
                    $field.find('option[value="'+default_val+'"]').attr('selected','selected');
                }
            });

            $('.mcsb_fa_preview i').removeAttr('class');

            //Remove selected option from shortcode selector.
            $shortcode_selector.find('option').prop('selected', false);
            $shortcode_selector.addClass('uk-hidden').removeClass('uk-animation-scale-up');

            //Remove animation classes and show first shortcode nav.
            $first_shortcode_nav.removeClass('uk-animation-scale-up uk-animation-reverse').show();

            //Reset child shortcode titles.
            $('.uk-nestable-list-item').each(function(){
                $(this).find('.mcsb-child-shortcode-title').html($(this).find('input.mcsb-shortcode-field[type="text"]').first().val());
            });

            //Hide shortcode options wrapper.
            $shortcode_options.hide();
            $('#mcsb-shortcode-options-wrapper').addClass('uk-hidden');

            //Hide shortcode preview
            $('#mcsb_shortcode_preview_holder').addClass('uk-hidden');

            //Reset color picker inputs color to default
            $('.mscb_color_picker').css('background-color', $('.mscb_color_picker').attr('data-default-bg')).css('color', $('.mscb_color_picker').attr('data-default-color'));

            //Remove active shortcode rel.
            $('#mcsb-active-shortcode-id').val('0');

            //Close shortcode builder modal.
            $('.uk-modal-close').trigger('click');
        },

        /*============================================================
        =            Clone new child for nested shortcode            =
        ============================================================*/
        add_child: function(shortcode_id){
            var clone = jQuery('#clone-'+shortcode_id).clone().removeClass('uk-hidden').removeAttr('id').addClass('uk-nestable-list-item-CLONE').addClass('uk-animation-scale-up');

            var child_count = jQuery('#clone-'+shortcode_id).parents('.mcsb-child-shortcode-options').find('li.uk-nestable-list-item').length;

            var clone_html = clone[0].outerHTML.split('-inc-').join(child_count);

            var $new_el = $(clone_html);

            jQuery('#clone-'+shortcode_id).before($new_el);

            setTimeout(function(){
                $('.uk-nestable-list-item-CLONE').removeClass('uk-animation-scale-up');
            }, 1000);

            mc_shortcode_builder.init_wp_color_picker();
        },

        /*===============================================
         =            Remove child shortcode            =
         ==============================================*/
        remove_child: function(el){
            el.closest('.uk-nestable-list-item').addClass('uk-animation-scale-up uk-animation-reverse').fadeOut('slow', function(){
                $(this).remove();

                mc_shortcode_builder.update_child_panel_order('all');
            });
        },

        /*========================================
        =     Toggle child shortcode options     =
        ========================================*/
        toggle_child: function(){
            $('.mcsb-child-shortcode-option-toggler').live('click', function(){
                var $toggler_icon = $(this).find('i');

                if( $toggler_icon.hasClass('uk-icon-minus') ){
                    $toggler_icon.removeClass('uk-icon-minus').addClass('uk-icon-plus');
                }else{
                    $toggler_icon.removeClass('uk-icon-plus').addClass('uk-icon-minus');
                }
            });
        },

        /*===========================================================
        =            Show selected options for shortcode            =
        ===========================================================*/
        switch_shortcode_options: function(){
            $first_shortcode_nav.find('li a').on('click', function(){
                var shortcode_id = $(this).attr('data-id');
                $shortcode_selector.removeClass('uk-hidden').addClass('uk-animation-scale-up');
                $shortcode_selector.find('option[value="'+shortcode_id+'"]').attr('selected','selected').change();

                $first_shortcode_nav.addClass('uk-animation-scale-up uk-animation-reverse').fadeOut(200);
            });

            $shortcode_selector.on('change', function() {
                var selected_shortcode_title = $(this).find('option:selected').text();
                var selected_shortcode_id = $(this).find('option:selected').val();
                var selected_shortcode_icon = $(this).find('option:selected').attr('data-icon');

                $shortcode_options.hide();
                $shortcode_options_label.text(selected_shortcode_title);
                $shortcode_options_label.parent().find('.uk-panel-title').find('i').remove();
                $shortcode_options_label.parent().find('.uk-panel-title').prepend('<i class="uk-icon-'+selected_shortcode_icon+'"></i> ');

                $('#mcsb-shortcode-options-wrapper').removeClass('uk-hidden');

                $(".mcsb-shortcode-options[data-shortcode-id='"+selected_shortcode_id+"']").fadeIn('slow');
                $('#mcsb-active-shortcode-id').val(selected_shortcode_id);
            });
        },

        /*=======================================
        =            WP Color picker            =
        =======================================*/
        init_wp_color_picker: function(){
            var iris_picker_selector = '.mscb_color_picker';

            $(iris_picker_selector).attr('data-default-bg', $(iris_picker_selector).css('background-color')).attr('data-default-color', $(iris_picker_selector).css('color'));

            $(iris_picker_selector).iris({
                change: function(event, ui) {
                    $(this).css('background-color', ui.color.toString()).css('color', mc_shortcode_builder.invert_hex_helper(ui.color.toString()));
                }
            });

            $(document).click(function (e) {
                if (!$(e.target).is(iris_picker_selector+", .iris-picker, .iris-picker-inner")) {
                    $(iris_picker_selector).iris('hide');
                    return false;
                }
            });

            $(iris_picker_selector).click(function (event) {
                $(iris_picker_selector).iris('hide');
                $(this).iris('show');
                return false;
            });
        },

        invert_hex_helper: function (hex) {
            var color = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            var rgb = Math.floor( (parseInt(color[1], 16) * 0.299 + parseInt(color[2], 16) * 0.587 + parseInt(color[3], 16) * 0.114) );

            if(rgb < 128){
                rgb = rgb / 2;
            }else{
                rgb += ( (255 - rgb) / 2 );
            }

            rgb = Math.floor(255 - rgb);

            var hex = rgb.toString(16);

            if(hex.length < 2){
                hex = '0'+hex;
            }

            color = hex + hex + hex;
            return '#'+color;
        },

        /*================================================
        =            Shortcode builder modals            =
        ================================================*/
        init_ui_modal: function(){

            var mcsb_modal_selector = '#mcsb_modal';
            var mcsb_fa_modal_selector = '#mcsb_fa_modal';

            /* Our popup needs to be higher z-index than LiveComposer popups */
            $(document).on({
                'uk.modal.show': function(){
                    jQuery('.uk-modal').css('z-index', '100000000000000000');
                },
            });

            /* FontAwesome icon selector modal events. */
            $(mcsb_fa_modal_selector).on({
                'uk.modal.show': function(){
                    //
                },

                'uk.modal.hide': function(){
                    $('#met_fa_rel').val(0);
                    $.UIkit.modal(mcsb_modal_selector).show();
                }
            });

            $('.mcsb_fa_button').live('click', function(){
                $.UIkit.modal(mcsb_fa_modal_selector).show();

                if( $(this).parents('div[id*="mcsb-child-shortcode-options_"]').get(0) ){
                    $('#met_fa_rel').val($(this).parents('div[id*="mcsb-child-shortcode-options_"]').attr('id'));
                }else if( $(this).parents('div[id*="mcsb-shortcode-options_"]').get(0) ){
                    $('#met_fa_rel').val($(this).parents('div[id*="mcsb-shortcode-options_"]').attr('id'));
                }
            });

            $('#mcsb_fa_modal_icon_list button').on('click', function(){
                var $target_options_wrapper_id = $('#met_fa_rel').val();
                var $target_options_wrapper = $('#'+$target_options_wrapper_id);

                var $fa_button = $target_options_wrapper.find('.mcsb_fa_button');
                var $fa_input = $fa_button.prev('.mcsb_fa_input');
                var $fa_preview = $fa_input.prev('.mcsb_fa_preview');

                var selected_icon_class = $(this).attr('data-icon');

                $fa_input.val('fa-'+selected_icon_class);
                $fa_preview.find('i').removeAttr('class');
                $fa_preview.find('i').attr('class','uk-icon-'+selected_icon_class);

                $('#met_fa_rel').val(0);
                $.UIkit.modal(mcsb_fa_modal_selector).hide();
            });
        },

        /*============================================================
         =            Update child shortcode panel title            =
         ===========================================================*/
        update_child_panel_title: function(){
            $('input.mcsb-shortcode-field[data-primary="1"]').live('change paste keyup', function(){
                $(this).parents('.uk-nestable-item').find('.mcsb-child-shortcode-title').html($(this).val());
            }).trigger('change');
        },

        /*============================================================
         =            Update child shortcode panel order            =
         ===========================================================*/
        update_child_panel_order: function(el){
            var $update_target_el;
            var uk_nli = 1;

            if( el == 'all' ){
                $('.mcsb-shortcode-options[data-shortcode-has-child="1"]').each(function(){
                    uk_nli = 1;
                    $(this).find('.uk-nestable-list-item').not('.uk-hidden').each(function(){
                        $(this).find('.mcsb-child-shortcode-order').html(uk_nli);
                        uk_nli++;
                    });
                });
            }else{
                el.find('.uk-nestable-list-item').not('.uk-hidden').each(function(){
                    $(this).find('.mcsb-child-shortcode-order').html(uk_nli);
                    uk_nli++;
                });
            }
        }
    };

    mc_shortcode_builder.init();

})(jQuery);